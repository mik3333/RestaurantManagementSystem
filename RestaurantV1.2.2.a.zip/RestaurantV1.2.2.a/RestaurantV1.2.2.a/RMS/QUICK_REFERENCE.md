# Quick Reference: What to Update

## UI/Design Changes

### Change Colors/Fonts/Spacing
- **File:** `src/view/ThemeConstants.java`
- **What:** Modify color constants (e.g., `PRIMARY_COLOR`, `DANGER_COLOR`)
- **Impact:** All UI components using that constant automatically update

### Add New Button Type
- **File:** `src/view/UIComponentFactory.java`
- **What:** Add new method like `createWarningButton(String text)`
- **Impact:** Any panel can now use the new button type

### Modify Panel Layout
- **File:** `src/view/*Panel.java` (e.g., `UsersPanel.java`)
- **What:** Adjust GridBagConstraints, add/remove fields
- **Impact:** Only that specific panel changes

---

## Business Logic Changes

### Change Permission Rules
- **File:** `src/service/StaffService.java` or `ProductService.java`
- **What:** Modify methods like `canCreateRole()`, `isAdmin()`
- **Impact:** Permission checks everywhere automatically use new rules

### Add Validation
- **File:** `src/service/StaffService.java` or `ProductService.java`
- **What:** Add method like `validateInput(...)` and call from UI
- **Impact:** Validation logic centralized, easy to update

### Change Business Behavior
- **File:** `src/service/*Service.java`
- **What:** Modify or add business logic methods
- **Impact:** No UI changes needed if service signature stays same

---

## Database Changes

### Add New SQL Query
- **File:** `src/database/*DAO.java` (e.g., `UserDAO.java`)
- **What:** Add new query method
- **Impact:** Can be called from Service layer

### Change Table Structure
- **File:** `database/schema.sql`
- **What:** Modify SQL schema
- **Impact:** Remember to update corresponding DAO queries

### Fix Database Bug
- **File:** `src/database/*DAO.java`
- **What:** Fix SQL query or connection logic
- **Impact:** Service and UI automatically use fixed version

---

## Adding a Complete New Feature

### Example: Add Export to CSV Feature

1. **Database:** Nothing needed (reading existing data)
2. **Service:** Add to `StaffService.java`:
   ```java
   public List<User> getAllStaffForExport() {
       return getAllStaff();
   }
   ```
3. **UI:** Add button to `UsersPanel.java`:
   ```java
   JButton exportBtn = UIComponentFactory.createPrimaryButton("Export");
   exportBtn.addActionListener(e -> exportToCSV());
   ```
4. **Implement:** `exportToCSV()` method in panel

### Example: Add New User Permission Level

1. **Model:** Verify `User.java` has role field ✓
2. **Database:** Add role to `schema.sql`, update `UserDAO.java`
3. **Service:** Add to `StaffService.java`:
   ```java
   public boolean canAccessReports(User user) {
       return user.getRole().equals("Admin") || user.getRole().equals("Manager");
   }
   ```
4. **UI:** Check permission and enable/disable features:
   ```java
   reportsButton.setEnabled(staffService.canAccessReports(currentUser));
   ```

---

## File Update Frequency

| Frequency | Files | Typical Updates |
|-----------|-------|-----------------|
| **Very Frequent** | `*Panel.java` | UI fixes, feature additions |
| **Frequent** | `*Service.java` | Business rule changes |
| **Occasional** | `*DAO.java`, `ThemeConstants.java` | New queries, design overhaul |
| **Rare** | `schema.sql`, Models | Database restructure |

---

## Common Mistakes to Avoid

❌ **Hardcoding colors in UI:**
```java
// BAD
button.setBackground(new Color(215, 72, 120));

// GOOD
button.setBackground(ThemeConstants.PRIMARY_COLOR);
```

❌ **Database queries in UI:**
```java
// BAD
userTable.getModel().addRow(userDAO.findAll());

// GOOD
List<User> users = staffService.getAllStaff();
// ... add to table
```

❌ **Mixing concerns:**
```java
// BAD
public void saveUser() {
    Connection conn = DriverManager.getConnection(...);
    // ... SQL code mixed with UI
}

// GOOD
public void saveUser() {
    boolean created = staffService.createStaffAccount(...);
    // ... just handle UI
}
```

---

## Testing After Changes

### After ThemeConstants change:
- Recompile and check all panels display new colors
- Verify consistency across Dashboard, UsersPanel, ProductsPanel

### After Service method change:
- Test with different user roles
- Verify permissions are enforced correctly

### After UI/Panel change:
- Check layout looks good at different screen sizes
- Verify all buttons work correctly
- Test with multiple user roles

---

## Need More Context?

Read `ARCHITECTURE.md` for detailed explanation of the modular design.
