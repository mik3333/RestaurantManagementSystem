-- Restaurant Management System SQL schema
-- This schema covers users, roles, products, categories, orders, order items, payments, tables, and kitchen tickets.
-- SQLite note: INTEGER PRIMARY KEY already auto-generates rowid values, so AUTOINCREMENT is unnecessary here.
-- Using INTEGER PRIMARY KEY avoids IDE/linter false positives from non-SQLite dialect parsers.
-- sonarlint-disable-all
-- This file contains valid SQLite syntax. IDE linter false positives are suppressed.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role_id INTEGER NOT NULL,
    display_name TEXT,
    status TEXT DEFAULT 'Active',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(role_id) REFERENCES roles(id)
);

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL DEFAULT 0.0,
    description TEXT,
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS restaurant_tables (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    seats INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'Available'
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY,
    order_number TEXT NOT NULL UNIQUE,
    user_id INTEGER,
    table_id INTEGER,
    status TEXT NOT NULL DEFAULT 'Open',
    subtotal REAL NOT NULL DEFAULT 0.0,
    tax REAL NOT NULL DEFAULT 0.0,
    discount REAL NOT NULL DEFAULT 0.0,
    total REAL NOT NULL DEFAULT 0.0,
    payment_status TEXT NOT NULL DEFAULT 'Pending',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(table_id) REFERENCES restaurant_tables(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price REAL NOT NULL DEFAULT 0.0,
    total_price REAL NOT NULL DEFAULT 0.0,
    notes TEXT,
    FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY(product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL,
    payment_method TEXT NOT NULL,
    amount_paid REAL NOT NULL DEFAULT 0.0,
    change_amount REAL NOT NULL DEFAULT 0.0,
    transaction_reference TEXT,
    paid_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(order_id) REFERENCES orders(id)
);

CREATE TABLE IF NOT EXISTS kitchen_tickets (
    id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL,
    ticket_number TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'Pending',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    FOREIGN KEY(order_id) REFERENCES orders(id)
);

-- Initial seed data for a prototype.
INSERT OR IGNORE INTO roles (id, name, description) VALUES
    (1, 'Admin', 'Administrator with full access'),
    (2, 'Manager', 'Manager with reporting and product access'),
    (3, 'Cashier', 'Cashier with POS access only');

INSERT OR IGNORE INTO users (id, username, password, role_id, display_name) VALUES
    (1, 'admin', '123', 1, 'Administrator');

INSERT OR IGNORE INTO categories (id, name, description) VALUES
    (1, 'Burger', 'All burger items'),
    (2, 'Pizza', 'Pizza items'),
    (3, 'Drinks', 'Beverages and drinks'),
    (4, 'BBQ', 'Barbecue items'),
    (5, 'Snacks', 'Light snacks');

INSERT OR IGNORE INTO products (id, name, category, price, description) VALUES
    (1, 'Zinger Burger', 'Burger', 250.0, 'Crispy chicken burger'),
    (2, 'Pizza', 'Pizza', 500.0, 'Cheese pizza'),
    (3, 'Sprite', 'Drinks', 80.0, 'Soft drink'),
    (4, 'Cheeze Lover', 'Burger', 380.0, 'Cheese lover burger'),
    (5, 'Double Zinger', 'Burger', 320.0, 'Double chicken burger'),
    (6, 'Chicken Burger', 'Burger', 280.0, 'Chicken burger'),
    (7, 'Double Chicken', 'Burger', 400.0, 'Double chicken burger'),
    (8, 'Beef Burger', 'Burger', 350.0, 'Beef burger'),
    (9, 'Chicken Wings', 'BBQ', 220.0, 'BBQ chicken wings'),
    (10, 'Chicken Kebab', 'BBQ', 300.0, 'Grilled chicken kebab'),
    (11, 'Samosa', 'Snacks', 50.0, 'Spicy snack'),
    (12, 'Korean Chicken BBQ', 'BBQ', 280.0, 'Korean-style chicken BBQ');

INSERT OR IGNORE INTO restaurant_tables (id, name, seats, status) VALUES
    (1, 'Table 1', 4, 'Available'),
    (2, 'Table 2', 4, 'Available'),
    (3, 'Table 3', 6, 'Available');
