package controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import service.ProductService;
import model.Product;

public class POSController implements service.ProductService.ProductChangeListener {

    private final Map<String, Product> productCatalog;
    private final List<CartItem> currentOrder;
    private final List<KitchenTicket> kitchenTickets;
    private final ProductService productService;

    public POSController() {
        this.productService = new ProductService();
        this.productCatalog = new HashMap<>();
        this.currentOrder = new ArrayList<>();
        this.kitchenTickets = new ArrayList<>();
        loadProductsFromService();
        productService.addProductChangeListener(this);
    }

    private void loadProductsFromService() {
        productCatalog.clear();
        try {
            List<Product> products = productService.getAllProducts();
            if (products != null && !products.isEmpty()) {
                for (Product p : products) {
                    productCatalog.put(p.getName(), p);
                }
                System.out.println("Loaded " + productCatalog.size() + " products from database");
            } else {
                System.out.println("No products found in database");
            }
        } catch (Exception e) {
            System.err.println("Error loading products: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onProductListChanged() {
        loadProductsFromService();
    }

    public void addToOrder(String productName, int quantity) {
        if (productCatalog.containsKey(productName) && quantity > 0) {
            Product product = productCatalog.get(productName);
            boolean found = false;
            for (CartItem item : currentOrder) {
                if (item.getProductId() == product.getId()) {
                    item.setQuantity(item.getQuantity() + quantity);
                    found = true;
                    break;
                }
            }
            if (!found) {
                CartItem item = new CartItem(product.getId(), productName, quantity, product.getPrice());
                currentOrder.add(item);
            }
        }
    }

    public void removeFromOrder(int index) {
        if (index >= 0 && index < currentOrder.size()) {
            currentOrder.remove(index);
        }
    }

    public void removeFromOrder(String productName) {
        if (productName == null || productName.trim().isEmpty()) {
            return;
        }
        currentOrder.removeIf(item -> item.getProductName().equals(productName));
    }

    public void decreaseOrderQuantity(String productName, int quantity) {
        if (productName == null || productName.trim().isEmpty() || quantity <= 0) {
            return;
        }
        for (int i = 0; i < currentOrder.size(); i++) {
            CartItem item = currentOrder.get(i);
            if (item.getProductName().equals(productName)) {
                int newQuantity = item.getQuantity() - quantity;
                if (newQuantity <= 0) {
                    currentOrder.remove(i);
                } else {
                    item.setQuantity(newQuantity);
                }
                return;
            }
        }
    }

    public void clearOrder() {
        currentOrder.clear();
    }

    public List<CartItem> getCurrentOrder() {
        return new ArrayList<>(currentOrder);
    }

    public double calculateTotal() {
        double total = 0;
        for (CartItem item : currentOrder) {
            total += item.getTotalAmount();
        }
        return total;
    }

    public Product getProduct(String productName) {
        return productCatalog.get(productName);
    }

    public KitchenTicket sendToKitchen() {
        if (currentOrder.isEmpty()) {
            return null;
        }
        KitchenTicket ticket = new KitchenTicket(new ArrayList<>(currentOrder));
        kitchenTickets.add(ticket);
        currentOrder.clear();
        return ticket;
    }

    public List<KitchenTicket> getKitchenTickets() {
        return new ArrayList<>(kitchenTickets);
    }

    public List<model.OrderItem> getOrderItems() {
        List<model.OrderItem> items = new ArrayList<>();
        for (CartItem item : currentOrder) {
            double totalPrice = item.getTotalAmount();
            items.add(new model.OrderItem(item.getProductId(), item.getQuantity(), item.getUnitPrice(), totalPrice, null));
        }
        return items;
    }

    public double calculateSubtotal() {
        return calculateTotal();
    }

    public double calculateTax() {
        // 12% VAT tax
        return calculateTotal() * 0.12;
    }

    public Map<String, Product> getProductCatalog() {
        return new HashMap<>(productCatalog);
    }

    // Get filtered products (for search/category filtering)
    private Map<String, Product> filteredProducts = null;

    public Map<String, Product> getFilteredProducts() {
        if (filteredProducts == null) {
            return getProductCatalog();
        }
        return filteredProducts;
    }

    public void searchProducts(String query) {
        if (query == null || query.trim().isEmpty()) {
            filteredProducts = null;
            System.out.println("Search cleared");
            return;
        }
        List<Product> products = productService.searchProducts(query);
        Map<String, Product> results = new HashMap<>();
        for (Product product : products) {
            results.put(product.getName(), product);
        }
        filteredProducts = results;
        System.out.println("Search for '" + query + "' found " + results.size() + " products");
    }

    public void filterByCategory(String category) {
        if (category == null || category.equals("All Categories") || category.trim().isEmpty()) {
            filteredProducts = null;
            System.out.println("Category filter cleared");
            return;
        }
        List<Product> products = productService.getProductsByCategory(category);
        Map<String, Product> results = new HashMap<>();
        for (Product product : products) {
            results.put(product.getName(), product);
        }
        filteredProducts = results;
        System.out.println("Filter by category '" + category + "' found " + results.size() + " products");
    }

    public void clearFilter() {
        filteredProducts = null;
    }

    public static class CartItem {
        private final int productId;
        private final String productName;
        private int quantity;
        private final double unitPrice;

        public CartItem(int productId, String productName, int quantity, double unitPrice) {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
        }

        public int getProductId() {
            return productId;
        }

        public String getProductName() {
            return productName;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public double getUnitPrice() {
            return unitPrice;
        }

        public double getTotalAmount() {
            return quantity * unitPrice;
        }
    }

    // KOT (Kitchen Order Ticket) - represents an order sent to the kitchen
    public static class KitchenTicket {
        private final String ticketId;
        private final List<CartItem> items;
        private final long timestamp;
        private boolean completed;

        public KitchenTicket(List<CartItem> items) {
            this.ticketId = "KOT-" + System.currentTimeMillis();
            this.items = new ArrayList<>(items);
            this.timestamp = System.currentTimeMillis();
            this.completed = false;
        }

        public String getTicketId() {
            return ticketId;
        }

        public List<CartItem> getItems() {
            return new ArrayList<>(items);
        }

        public long getTimestamp() {
            return timestamp;
        }

        public boolean isCompleted() {
            return completed;
        }

        public void markCompleted() {
            this.completed = true;
        }
    }
}
