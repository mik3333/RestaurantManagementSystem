package controller;

import database.UserDAO;
import model.User;

import java.util.Optional;

public class LoginController {

    private final UserDAO userDAO = new UserDAO();

    public Optional<User> authenticate(String username, String password) {
        if (username == null || password == null) {
            return Optional.empty();
        }

        return userDAO.authenticate(username.trim(), password.trim());
    }
}
