package database;

import model.Order;
import model.OrderItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    public int createOrder(Order order) {
        Connection connection = null;
        try {
            connection = DatabaseManager.connect();
            connection.setAutoCommit(false);

            // Insert order
            String orderSql = "INSERT INTO orders (order_number, user_id, table_id, status, subtotal, tax, discount, total, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement orderStmt = connection.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                orderStmt.setString(1, order.getOrderNumber());
                orderStmt.setInt(2, order.getUserId());
                if (order.getTableId() != null) {
                    orderStmt.setInt(3, order.getTableId());
                } else {
                    orderStmt.setNull(3, Types.INTEGER);
                }
                orderStmt.setString(4, order.getStatus());
                orderStmt.setDouble(5, order.getSubtotal());
                orderStmt.setDouble(6, order.getTax());
                orderStmt.setDouble(7, order.getDiscount());
                orderStmt.setDouble(8, order.getTotal());
                orderStmt.setString(9, order.getPaymentStatus());

                int orderResult = orderStmt.executeUpdate();
                if (orderResult != 1) {
                    connection.rollback();
                    return -1;
                }

                // Get generated order ID
                try (ResultSet generatedKeys = orderStmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int orderId = generatedKeys.getInt(1);

                        // Insert order items
                        String itemSql = "INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price, notes) VALUES (?, ?, ?, ?, ?, ?)";
                        try (PreparedStatement itemStmt = connection.prepareStatement(itemSql)) {
                            for (OrderItem item : order.getItems()) {
                                itemStmt.setInt(1, orderId);
                                itemStmt.setInt(2, item.getProductId());
                                itemStmt.setInt(3, item.getQuantity());
                                itemStmt.setDouble(4, item.getUnitPrice());
                                itemStmt.setDouble(5, item.getTotalPrice());
                                itemStmt.setString(6, item.getNotes());
                                itemStmt.addBatch();
                            }
                            itemStmt.executeBatch();
                        }
                        
                        connection.commit();
                        return orderId;
                    }
                }
            }

            connection.commit();
            return -1;
        } catch (SQLException e) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            throw new RuntimeException("Failed to create order", e);
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(true);
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public boolean createPayment(int orderId, String paymentMethod, double amountPaid, double changeAmount, String transactionReference) {
        String sql = "INSERT INTO payments (order_id, payment_method, amount_paid, change_amount, transaction_reference) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderId);
            statement.setString(2, paymentMethod);
            statement.setDouble(3, amountPaid);
            statement.setDouble(4, changeAmount);
            statement.setString(5, transactionReference);
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create payment", e);
        }
    }

    public boolean updateOrderStatus(int orderId, String status) {
        String sql = "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            statement.setInt(2, orderId);
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update order status", e);
        }
    }

    public Order findById(int id) {
        String sql = "SELECT * FROM orders WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    List<OrderItem> items = findOrderItems(id);
                    return new Order(
                            rs.getInt("id"),
                            rs.getString("order_number"),
                            rs.getInt("user_id"),
                            rs.getInt("table_id"),
                            rs.getString("status"),
                            rs.getDouble("subtotal"),
                            rs.getDouble("tax"),
                            rs.getDouble("discount"),
                            rs.getDouble("total"),
                            rs.getString("payment_status"),
                            rs.getString("created_at"),
                            rs.getString("updated_at"),
                            items
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find order", e);
        }
        return null;
    }

    /**
     * Get all completed orders for reports
     */
    public List<Order> findAllCompleted() {
        String sql = "SELECT * FROM orders WHERE status = 'Completed' ORDER BY created_at DESC";
        List<Order> orders = new ArrayList<>();
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                int orderId = rs.getInt("id");
                List<OrderItem> items = findOrderItems(orderId);
                orders.add(new Order(
                        orderId,
                        rs.getString("order_number"),
                        rs.getInt("user_id"),
                        rs.getInt("table_id"),
                        rs.getString("status"),
                        rs.getDouble("subtotal"),
                        rs.getDouble("tax"),
                        rs.getDouble("discount"),
                        rs.getDouble("total"),
                        rs.getString("payment_status"),
                        rs.getString("created_at"),
                        rs.getString("updated_at"),
                        items
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load orders", e);
        }
        return orders;
    }

    /**
     * Get payment info for an order
     */
    public PaymentInfo findPaymentByOrderId(int orderId) {
        String sql = "SELECT * FROM payments WHERE order_id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderId);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return new PaymentInfo(
                            rs.getInt("id"),
                            rs.getString("payment_method"),
                            rs.getDouble("amount_paid"),
                            rs.getDouble("change_amount"),
                            rs.getString("transaction_reference"),
                            rs.getString("paid_at")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find payment", e);
        }
        return null;
    }

    /**
     * Payment info holder
     */
    public static class PaymentInfo {
        private final int id;
        private final String paymentMethod;
        private final double amountPaid;
        private final double changeAmount;
        private final String transactionReference;
        private final String paidAt;

        public PaymentInfo(int id, String paymentMethod, double amountPaid, double changeAmount, 
                          String transactionReference, String paidAt) {
            this.id = id;
            this.paymentMethod = paymentMethod;
            this.amountPaid = amountPaid;
            this.changeAmount = changeAmount;
            this.transactionReference = transactionReference;
            this.paidAt = paidAt;
        }

        public int getId() { return id; }
        public String getPaymentMethod() { return paymentMethod; }
        public double getAmountPaid() { return amountPaid; }
        public double getChangeAmount() { return changeAmount; }
        public String getTransactionReference() { return transactionReference; }
        public String getPaidAt() { return paidAt; }
    }

    private List<OrderItem> findOrderItems(int orderId) {
        String sql = "SELECT * FROM order_items WHERE order_id = ?";
        List<OrderItem> items = new ArrayList<>();
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    items.add(new OrderItem(
                            rs.getInt("id"),
                            rs.getInt("order_id"),
                            rs.getInt("product_id"),
                            rs.getInt("quantity"),
                            rs.getDouble("unit_price"),
                            rs.getDouble("total_price"),
                            rs.getString("notes")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load order items", e);
        }
        return items;
    }
}