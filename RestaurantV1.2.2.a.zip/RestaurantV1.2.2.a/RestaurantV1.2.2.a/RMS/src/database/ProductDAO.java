package database;

import model.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public List<Product> findAll() {
        String sql = "SELECT id, name, category, price, description FROM products ORDER BY name";
        List<Product> products = new ArrayList<>();

        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                products.add(new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("category"),
                        rs.getDouble("price"),
                        rs.getString("description")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load products", e);
        }
        return products;
    }

    public boolean createProduct(String name, String category, double price, String description) {
        String sql = "INSERT INTO products (name, category, price, description) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name.trim());
            statement.setString(2, category.trim());
            statement.setDouble(3, price);
            statement.setString(4, description.trim());
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create product", e);
        }
    }

    public boolean deleteProduct(int id) {
        String sql = "DELETE FROM products WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete product", e);
        }
    }

    public boolean updateProduct(int id, String name, String category, double price, String description) {
        String sql = "UPDATE products SET name = ?, category = ?, price = ?, description = ? WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name.trim());
            statement.setString(2, category.trim());
            statement.setDouble(3, price);
            statement.setString(4, description.trim());
            statement.setInt(5, id);
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update product", e);
        }
    }

    /**
     * Find product by ID
     */
    public Product findById(int id) {
        String sql = "SELECT id, name, category, price, description FROM products WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return new Product(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getString("description")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find product", e);
        }
        return null;
    }

    /**
     * Find product by name
     */
    public Product findByName(String name) {
        String sql = "SELECT id, name, category, price, description FROM products WHERE name = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return new Product(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getString("description")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find product by name", e);
        }
        return null;
    }

    /**
     * Search products by name or description fragment
     */
    public List<Product> findByNameFragment(String fragment) {
        String sql = "SELECT id, name, category, price, description FROM products WHERE lower(name) LIKE ? OR lower(description) LIKE ? ORDER BY name";
        List<Product> products = new ArrayList<>();
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            String query = "%" + fragment.toLowerCase().trim() + "%";
            statement.setString(1, query);
            statement.setString(2, query);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    products.add(new Product(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getString("description")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to search products", e);
        }
        return products;
    }

    /**
     * Search products by category
     */
    public List<Product> findByCategory(String category) {
        String sql = "SELECT id, name, category, price, description FROM products WHERE lower(category) = ? ORDER BY name";
        List<Product> products = new ArrayList<>();
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, category.toLowerCase().trim());
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    products.add(new Product(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getString("description")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load products by category", e);
        }
        return products;
    }
}
