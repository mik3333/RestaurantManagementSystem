package database;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;

public class DatabaseManager {
    private static final String DB_FILE = "data/restaurant.db";
    private static final String SCHEMA_FILE = "database/schema.sql";
    private static final String JDBC_DRIVER_JAR = "lib/sqlite-jdbc-3.42.0.0.jar";

    public static Connection connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            loadDriverJar();
        }
        return DriverManager.getConnection(buildJdbcUrl());
    }

    private static void loadDriverJar() throws SQLException {
        Path jarPath = resolveProjectPath(JDBC_DRIVER_JAR);
        if (!Files.exists(jarPath)) {
            throw new SQLException("SQLite JDBC driver jar not found at: " + jarPath.toAbsolutePath());
        }

        try {
            URL jarUrl = jarPath.toUri().toURL();
            URLClassLoader loader = new URLClassLoader(new URL[]{jarUrl}, Thread.currentThread().getContextClassLoader());
            Class<?> driverClass = Class.forName("org.sqlite.JDBC", true, loader);
            Driver driver = (Driver) driverClass.getDeclaredConstructor().newInstance();
            DriverManager.registerDriver(new DriverShim(driver));
        } catch (Exception ex) {
            throw new SQLException("Failed to load SQLite JDBC driver from jar", ex);
        }
    }

    public static void initializeDatabase() throws IOException, SQLException {
        Path dbFile = resolveProjectPath(DB_FILE);
        Path dbDir = dbFile.getParent();
        if (dbDir != null && !Files.exists(dbDir)) {
            Files.createDirectories(dbDir);
        }

        String schema = readSchema();
        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");

            Arrays.stream(schema.split(";"))
                    .map(String::trim)
                    .filter(sql -> !sql.isEmpty())
                    .forEach(sql -> {
                        try {
                            statement.execute(sql);
                        } catch (SQLException e) {
                            throw new RuntimeException("Failed to execute SQL statement: " + sql, e);
                        }
                    });
        }
    }

    private static String readSchema() throws IOException {
        Path schemaPath = resolveProjectPath(SCHEMA_FILE);
        if (!Files.exists(schemaPath)) {
            throw new IOException("Schema file not found: " + schemaPath.toAbsolutePath());
        }
        return new String(Files.readAllBytes(schemaPath), StandardCharsets.UTF_8);
    }

    private static String buildJdbcUrl() {
        return "jdbc:sqlite:" + resolveProjectPath(DB_FILE).toAbsolutePath();
    }

    private static Path resolveProjectPath(String relativePath) {
        return resolveProjectRoot().resolve(relativePath).normalize();
    }

    private static Path resolveProjectRoot() {
        Path currentDir = Paths.get("").toAbsolutePath().normalize();

        if (looksLikeProjectRoot(currentDir)) {
            return currentDir;
        }

        Path nestedRmsDir = currentDir.resolve("RMS");
        if (looksLikeProjectRoot(nestedRmsDir)) {
            return nestedRmsDir;
        }

        return currentDir;
    }

    private static boolean looksLikeProjectRoot(Path dir) {
        return Files.exists(dir.resolve(SCHEMA_FILE))
                && Files.exists(dir.resolve(JDBC_DRIVER_JAR));
    }

    private static class DriverShim implements Driver {
        private final Driver delegate;

        public DriverShim(Driver delegate) {
            this.delegate = delegate;
        }

        @Override
        public Connection connect(String url, Properties info) throws SQLException {
            return delegate.connect(url, info);
        }

        @Override
        public boolean acceptsURL(String url) throws SQLException {
            return delegate.acceptsURL(url);
        }

        @Override
        public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {
            return delegate.getPropertyInfo(url, info);
        }

        @Override
        public int getMajorVersion() {
            return delegate.getMajorVersion();
        }

        @Override
        public int getMinorVersion() {
            return delegate.getMinorVersion();
        }

        @Override
        public boolean jdbcCompliant() {
            return delegate.jdbcCompliant();
        }

        @Override
        public Logger getParentLogger() throws SQLFeatureNotSupportedException {
            return delegate.getParentLogger();
        }
    }
}
