package database;

import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UserDAO {

    public Optional<User> authenticate(String username, String password) {
        String sql = "SELECT u.username, r.name AS role_name FROM users u "
                + "JOIN roles r ON u.role_id = r.id "
                + "WHERE u.username = ? AND u.password = ?";

        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username.trim());
            statement.setString(2, password.trim());
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new User(rs.getString("username"), rs.getString("role_name")));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to authenticate user", e);
        }
        return Optional.empty();
    }

    public boolean createUser(String username, String password, String role) {
        String roleQuery = "SELECT id FROM roles WHERE name = ?";
        String userInsert = "INSERT INTO users (username, password, role_id, display_name) VALUES (?, ?, ?, ?)";

        try (Connection connection = DatabaseManager.connect();
             PreparedStatement roleStmt = connection.prepareStatement(roleQuery)) {
            roleStmt.setString(1, role.trim());
            try (ResultSet rs = roleStmt.executeQuery()) {
                if (!rs.next()) {
                    return false;
                }
                int roleId = rs.getInt("id");
                try (PreparedStatement insertStmt = connection.prepareStatement(userInsert)) {
                    insertStmt.setString(1, username.trim());
                    insertStmt.setString(2, password.trim());
                    insertStmt.setInt(3, roleId);
                    insertStmt.setString(4, username.trim());
                    insertStmt.executeUpdate();
                    return true;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create user", e);
        }
    }

    public boolean userExists(String username) {
        String sql = "SELECT 1 FROM users WHERE username = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username.trim());
            try (ResultSet rs = statement.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to query user existence", e);
        }
    }

    public List<User> findAllUsers() {
        String sql = "SELECT u.username, r.name AS role_name FROM users u "
                + "JOIN roles r ON u.role_id = r.id ORDER BY u.username";
        List<User> users = new ArrayList<>();
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                users.add(new User(rs.getString("username"), rs.getString("role_name")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load users", e);
        }
        return users;
    }

    public boolean deleteUser(String username) {
        String sql = "DELETE FROM users WHERE username = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username.trim());
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete user", e);
        }
    }

    public boolean updateUserRole(String username, String newRole) {
        String roleQuery = "SELECT id FROM roles WHERE name = ?";
        String userUpdate = "UPDATE users SET role_id = ? WHERE username = ?";

        try (Connection connection = DatabaseManager.connect();
             PreparedStatement roleStmt = connection.prepareStatement(roleQuery)) {
            roleStmt.setString(1, newRole.trim());
            try (ResultSet rs = roleStmt.executeQuery()) {
                if (!rs.next()) {
                    return false;
                }
                int roleId = rs.getInt("id");
                try (PreparedStatement updateStmt = connection.prepareStatement(userUpdate)) {
                    updateStmt.setInt(1, roleId);
                    updateStmt.setString(2, username.trim());
                    return updateStmt.executeUpdate() == 1;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update user role", e);
        }
    }
}
