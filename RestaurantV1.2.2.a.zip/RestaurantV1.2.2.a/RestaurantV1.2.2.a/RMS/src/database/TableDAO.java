package database;

import model.Table;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TableDAO {

    public List<Table> findAll() {
        String sql = "SELECT id, name, seats, status FROM restaurant_tables ORDER BY name";
        List<Table> tables = new ArrayList<>();

        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                tables.add(new Table(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("seats"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load tables", e);
        }
        return tables;
    }

    public List<Table> findAvailable() {
        String sql = "SELECT id, name, seats, status FROM restaurant_tables WHERE status = 'Available' ORDER BY name";
        List<Table> tables = new ArrayList<>();

        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                tables.add(new Table(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("seats"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load available tables", e);
        }
        return tables;
    }

    public Table findById(int id) {
        String sql = "SELECT id, name, seats, status FROM restaurant_tables WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return new Table(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getInt("seats"),
                            rs.getString("status")
                    );
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to find table", e);
        }
        return null;
    }

    public boolean updateStatus(int id, String status) {
        String sql = "UPDATE restaurant_tables SET status = ? WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            statement.setInt(2, id);
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update table status", e);
        }
    }

    public boolean createTable(String name, int seats) {
        String sql = "INSERT INTO restaurant_tables (name, seats, status) VALUES (?, ?, 'Available')";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, seats);
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create table", e);
        }
    }
}