package database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KitchenTicketDAO {

    public int createTicket(int orderId, String ticketNumber) {
        String sql = "INSERT INTO kitchen_tickets (order_id, ticket_number, status) VALUES (?, ?, 'Preparing')";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, orderId);
            statement.setString(2, ticketNumber);
            int result = statement.executeUpdate();
            if (result == 1) {
                ResultSet rs = statement.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create kitchen ticket", e);
        }
        return -1;
    }

    public List<KitchenTicketInfo> findAll() {
        String sql = "SELECT kt.id, kt.order_id, kt.ticket_number, kt.status, kt.created_at, kt.completed_at, " +
                     "o.order_number, o.table_id FROM kitchen_tickets kt " +
                     "JOIN orders o ON kt.order_id = o.id ORDER BY kt.created_at DESC";
        List<KitchenTicketInfo> tickets = new ArrayList<>();
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                tickets.add(new KitchenTicketInfo(
                        rs.getInt("id"),
                        rs.getInt("order_id"),
                        rs.getString("ticket_number"),
                        rs.getString("status"),
                        rs.getString("created_at"),
                        rs.getString("completed_at"),
                        rs.getString("order_number"),
                        rs.getObject("table_id") != null ? rs.getInt("table_id") : null
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to load kitchen tickets", e);
        }
        return tickets;
    }

    public boolean updateStatus(int ticketId, String status) {
        String sql = "UPDATE kitchen_tickets SET status = ?, completed_at = CASE WHEN ? = 'Served' THEN CURRENT_TIMESTAMP ELSE completed_at END WHERE id = ?";
        try (Connection connection = DatabaseManager.connect();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            statement.setString(2, status);
            statement.setInt(3, ticketId);
            return statement.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update ticket status", e);
        }
    }

    public static class KitchenTicketInfo {
        private final int id;
        private final int orderId;
        private final String ticketNumber;
        private final String status;
        private final String createdAt;
        private final String completedAt;
        private final String orderNumber;
        private final Integer tableId;

        public KitchenTicketInfo(int id, int orderId, String ticketNumber, String status, 
                                 String createdAt, String completedAt, String orderNumber, Integer tableId) {
            this.id = id;
            this.orderId = orderId;
            this.ticketNumber = ticketNumber;
            this.status = status;
            this.createdAt = createdAt;
            this.completedAt = completedAt;
            this.orderNumber = orderNumber;
            this.tableId = tableId;
        }

        public int getId() { return id; }
        public int getOrderId() { return orderId; }
        public String getTicketNumber() { return ticketNumber; }
        public String getStatus() { return status; }
        public String getCreatedAt() { return createdAt; }
        public String getCompletedAt() { return completedAt; }
        public String getOrderNumber() { return orderNumber; }
        public Integer getTableId() { return tableId; }
    }
}