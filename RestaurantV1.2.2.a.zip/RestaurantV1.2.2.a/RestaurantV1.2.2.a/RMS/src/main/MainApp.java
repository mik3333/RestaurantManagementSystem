package main;

import database.DatabaseManager;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import view.LoginForm;

public class MainApp {
    public static void main(String[] args) {
        try {
            DatabaseManager.initializeDatabase();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to initialize database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        SwingUtilities.invokeLater(() -> {
            new LoginForm();
        });
    }
}
