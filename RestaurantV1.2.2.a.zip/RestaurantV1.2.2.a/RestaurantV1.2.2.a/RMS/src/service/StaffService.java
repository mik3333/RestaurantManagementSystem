package service;

import database.UserDAO;
import model.User;

import java.util.List;

/**
 * Service layer for staff management operations.
 * Encapsulates business logic and provides a clean interface for UI components.
 * Update this class instead of database classes to modify staff management behavior.
 */
public class StaffService {

    private final UserDAO userDAO;

    public StaffService() {
        this.userDAO = new UserDAO();
    }

    /**
     * Get all users in the system
     */
    public List<User> getAllStaff() {
        return userDAO.findAllUsers();
    }

    /**
     * Create a new user account
     */
    public boolean createStaffAccount(String username, String password, String role) {
        return userDAO.createUser(username, password, role);
    }

    /**
     * Check if a username already exists
     */
    public boolean staffExists(String username) {
        return userDAO.userExists(username);
    }

    /**
     * Delete a staff account
     */
    public boolean deleteStaffAccount(String username) {
        return userDAO.deleteUser(username);
    }

    /**
     * Update a staff member's role
     */
    public boolean updateStaffRole(String username, String newRole) {
        return userDAO.updateUserRole(username, newRole);
    }

    /**
     * Validate if a user can create an account with a specific role
     */
    public boolean canCreateRole(User currentUser, String roleToCreate) {
        if (currentUser.getRole().equals("Admin")) {
            return true; // Admin can create any role
        } else if (currentUser.getRole().equals("Manager")) {
            return roleToCreate.equals("Cashier"); // Manager can only create Cashier
        }
        return false; // Cashier cannot create any role
    }

    /**
     * Get the available roles that a user can create
     */
    public String[] getAvailableRolesToCreate(User currentUser) {
        if (currentUser.getRole().equals("Admin")) {
            return new String[]{"Manager", "Cashier"};
        } else if (currentUser.getRole().equals("Manager")) {
            return new String[]{"Cashier"};
        }
        return new String[]{};
    }

    /**
     * Check if a user can perform admin operations
     */
    public boolean isAdmin(User user) {
        return user.getRole().equals("Admin");
    }

    /**
     * Check if a user can manage staff
     */
    public boolean canManageStaff(User user) {
        return user.getRole().equals("Admin") || user.getRole().equals("Manager");
    }

    /**
     * Check if the admin account can be modified
     */
    public boolean isProtectedAccount(String username) {
        return username.equals("admin");
    }
}
