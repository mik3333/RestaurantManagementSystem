package service;

import database.OrderDAO;
import database.TableDAO;
import database.KitchenTicketDAO;
import model.Order;
import model.OrderItem;
import model.User;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Service layer for order management operations.
 * Handles checkout business logic, transaction ID generation, and table status updates.
 */
public class OrderService {

    private final OrderDAO orderDAO;
    private final TableDAO tableDAO;
    private final KitchenTicketDAO kitchenTicketDAO;
    private final Random random = new Random();

    public OrderService() {
        this.orderDAO = new OrderDAO();
        this.tableDAO = new TableDAO();
        this.kitchenTicketDAO = new KitchenTicketDAO();
    }

    /**
     * Get all completed orders for reports
     */
    public List<Order> getCompletedOrders() {
        return orderDAO.findAllCompleted();
    }

    /**
     * Get payment info for an order
     */
    public OrderDAO.PaymentInfo getPaymentInfo(int orderId) {
        return orderDAO.findPaymentByOrderId(orderId);
    }

    /**
     * Get all kitchen tickets
     */
    public List<KitchenTicketDAO.KitchenTicketInfo> getKitchenTickets() {
        return kitchenTicketDAO.findAll();
    }

    /**
     * Update kitchen ticket status
     */
    public boolean updateKitchenTicketStatus(int ticketId, String status) {
        return kitchenTicketDAO.updateStatus(ticketId, status);
    }

    /**
     * Process checkout for an order
     */
    public CheckoutResult checkout(Order order, String paymentMethod, User cashier) {
        // Generate transaction ID
        String transactionId = generateTransactionId();

        // Create order in database and get the generated order ID
        int orderId = orderDAO.createOrder(order);
        if (orderId <= 0) {
            return new CheckoutResult(false, "Failed to create order", null, null);
        }

        // Create kitchen ticket
        String ticketNumber = generateTicketNumber();
        int ticketId = kitchenTicketDAO.createTicket(orderId, ticketNumber);
        if (ticketId <= 0) {
            // Log warning but don't fail the order
            System.out.println("Warning: Failed to create kitchen ticket for order " + orderId);
        }

        // Create payment record
        boolean paymentCreated = orderDAO.createPayment(orderId, paymentMethod, order.getTotal(), 0.0, transactionId);
        if (!paymentCreated) {
            return new CheckoutResult(false, "Failed to process payment", null, null);
        }

        // Update order status to completed
        orderDAO.updateOrderStatus(orderId, "Completed");

        // Update table status to Occupied if table was assigned
        if (order.getTableId() != null) {
            tableDAO.updateStatus(order.getTableId(), "Occupied");
        }

        // Get current timestamp for receipt
        String paymentDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        return new CheckoutResult(true, "Checkout successful", transactionId, paymentDate);
    }

    /**
     * Generate unique kitchen ticket number
     */
    private String generateTicketNumber() {
        LocalDateTime now = LocalDateTime.now();
        String timestamp = now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        int randomNum = random.nextInt(9000) + 1000;
        return "KT-" + timestamp + "-" + randomNum;
    }

    /**
     * Generate unique transaction ID
     */
    private String generateTransactionId() {
        LocalDateTime now = LocalDateTime.now();
        String timestamp = now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        int randomNum = random.nextInt(9000) + 1000; // 4-digit random number
        return "TXN-" + timestamp + "-" + randomNum;
    }

    /**
     * Result of checkout operation
     */
    public static class CheckoutResult {
        private final boolean success;
        private final String message;
        private final String transactionId;
        private final String paymentDate;

        public CheckoutResult(boolean success, String message, String transactionId, String paymentDate) {
            this.success = success;
            this.message = message;
            this.transactionId = transactionId;
            this.paymentDate = paymentDate;
        }

        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public String getTransactionId() { return transactionId; }
        public String getPaymentDate() { return paymentDate; }
    }
}