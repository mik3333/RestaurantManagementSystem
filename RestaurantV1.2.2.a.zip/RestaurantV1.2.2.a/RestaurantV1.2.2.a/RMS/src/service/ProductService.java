package service;

import database.ProductDAO;
import model.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * Service layer for product management operations.
 * Encapsulates business logic and provides a clean interface for UI components.
 * Update this class instead of database classes to modify product management behavior.
 */
public class ProductService {

    private final ProductDAO productDAO;
    private final List<ProductChangeListener> listeners = new ArrayList<>();

    public interface ProductChangeListener {
        void onProductListChanged();
    }

    public void addProductChangeListener(ProductChangeListener listener) {
        listeners.add(listener);
    }

    public void removeProductChangeListener(ProductChangeListener listener) {
        listeners.remove(listener);
    }

    private void notifyProductChange() {
        for (ProductChangeListener listener : listeners) {
            listener.onProductListChanged();
        }
    }

    public ProductService() {
        this.productDAO = new ProductDAO();
    }

    /**
     * Get all products in the catalog
     */
    public List<Product> getAllProducts() {
        return productDAO.findAll();
    }

    /**
     * Get product by name
     */
    public Product getProductByName(String name) {
        return productDAO.findByName(name);
    }

    /**
     * Search products by keyword fragment
     */
    public List<Product> searchProducts(String fragment) {
        if (fragment == null || fragment.trim().isEmpty()) {
            return getAllProducts();
        }
        return productDAO.findByNameFragment(fragment);
    }

    /**
     * Get products by exact category name
     */
    public List<Product> getProductsByCategory(String category) {
        if (category == null || category.trim().isEmpty() || category.equals("All Categories")) {
            return getAllProducts();
        }
        return productDAO.findByCategory(category);
    }

    /**
     * Add a new product to the catalog
     */
    public boolean addProduct(String name, String category, double price, String description) {
        boolean result = productDAO.createProduct(name, category, price, description);
        if (result) notifyProductChange();
        return result;
    }

    /**
     * Remove a product from the catalog
     */
    public boolean removeProduct(int productId) {
        boolean result = productDAO.deleteProduct(productId);
        if (result) notifyProductChange();
        return result;
    }

    /**
     * Update product information
     */
    public boolean updateProduct(int productId, String name, String category, double price, String description) {
        boolean result = productDAO.updateProduct(productId, name, category, price, description);
        if (result) notifyProductChange();
        return result;
    }

    /**
     * Validate product data before saving
     */
    public String validateProduct(String name, String category, String priceStr, String description) {
        if (name.isEmpty() || category.isEmpty() || priceStr.isEmpty()) {
            return "Please fill in all required fields.";
        }

        try {
            Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            return "Price must be a valid number.";
        }

        return null; // No errors
    }

    /**
     * Parse price string to double
     */
    public double parsePrice(String priceStr) throws NumberFormatException {
        return Double.parseDouble(priceStr);
    }

    /**
     * Check if user can edit/add products
     */
    public boolean canEditProducts(User user) {
        return user.getRole().equals("Admin") || user.getRole().equals("Manager");
    }

    /**
     * Check if user can delete products
     */
    public boolean canDeleteProducts(User user) {
        return user.getRole().equals("Admin");
    }
}
