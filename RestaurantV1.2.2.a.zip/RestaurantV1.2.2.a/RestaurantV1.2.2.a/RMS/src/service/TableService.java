package service;

import database.TableDAO;
import model.Table;
import model.User;

import java.util.List;

/**
 * Service layer for table management operations.
 * Encapsulates business logic and provides a clean interface for UI components.
 */
public class TableService {

    private final TableDAO tableDAO;

    public TableService() {
        this.tableDAO = new TableDAO();
    }

    /**
     * Get all tables
     */
    public List<Table> getAllTables() {
        return tableDAO.findAll();
    }

    /**
     * Get available tables
     */
    public List<Table> getAvailableTables() {
        return tableDAO.findAvailable();
    }

    /**
     * Find table by ID
     */
    public Table getTableById(int id) {
        return tableDAO.findById(id);
    }

    /**
     * Update table status
     */
    public boolean updateTableStatus(int tableId, String status) {
        return tableDAO.updateStatus(tableId, status);
    }

    /**
     * Create a new table
     */
    public boolean createTable(String name, int seats) {
        return tableDAO.createTable(name, seats);
    }

    /**
     * Check if user can manage tables
     */
    public boolean canManageTables(User user) {
        String role = user.getRole();
        return role.equals("Admin") || role.equals("Manager") || role.equals("Cashier");
    }
}