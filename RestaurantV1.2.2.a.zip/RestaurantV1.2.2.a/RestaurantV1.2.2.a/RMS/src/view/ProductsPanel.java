package view;

import database.ProductDAO;
import model.Product;
import model.User;
import service.ProductService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ProductsPanel extends JPanel {

    private final ProductService productService = new ProductService();
    private final User currentUser;
    private DefaultTableModel tableModel;
    private JTextField nameField;
    private JTextField categoryField;
    private JTextField priceField;
    private JTextArea descriptionArea;
    private JTable productTable;
    private JButton createButton;
    private JButton deleteButton;
    private JButton editButton;

    public ProductsPanel(User currentUser) {
        this.currentUser = currentUser;
        setLayout(new BorderLayout(12, 12));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel title = new JLabel("Product Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(34, 44, 82));

        add(title, BorderLayout.NORTH);
        add(createProductTable(), BorderLayout.CENTER);
        add(createForm(), BorderLayout.SOUTH);

        loadProducts();
    }

    private JComponent createProductTable() {
        String[] columns = {"ID", "Name", "Category", "Price", "Description"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        productTable = new JTable(tableModel);
        productTable.setRowHeight(32);
        JScrollPane scrollPane = new JScrollPane(productTable);
        scrollPane.setPreferredSize(new Dimension(0, 240));
        return scrollPane;
    }

    private JComponent createForm() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel nameLabel = new JLabel("Product Name");
        nameField = new JTextField(20);

        JLabel categoryLabel = new JLabel("Category");
        categoryField = new JTextField(20);

        JLabel priceLabel = new JLabel("Price");
        priceField = new JTextField(20);

        JLabel descriptionLabel = new JLabel("Description");
        descriptionArea = new JTextArea(3, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane descriptionScroll = new JScrollPane(descriptionArea);

        JButton createButton = new JButton("Add Product");
        createButton.addActionListener(e -> saveProduct());
        createButton.setEnabled(productService.canEditProducts(currentUser));
        this.createButton = createButton;

        JButton deleteButton = new JButton("Delete Selected");
        deleteButton.setBackground(new Color(211, 47, 47));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.addActionListener(e -> deleteSelectedProduct());
        deleteButton.setEnabled(productService.canDeleteProducts(currentUser));
        this.deleteButton = deleteButton;

        JButton editButton = new JButton("Edit Selected");
        editButton.setBackground(new Color(56, 142, 60));
        editButton.setForeground(Color.WHITE);
        editButton.addActionListener(e -> editSelectedProduct());
        editButton.setEnabled(productService.canEditProducts(currentUser));
        this.editButton = editButton;

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(categoryLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(categoryField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(priceLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(priceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(descriptionLabel, gbc);
        gbc.gridx = 1;
        formPanel.add(descriptionScroll, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(createButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(editButton);
        formPanel.add(buttonPanel, gbc);

        return formPanel;
    }

    private void loadProducts() {
        tableModel.setRowCount(0);
        List<Product> products = productService.getAllProducts();
        for (Product product : products) {
            tableModel.addRow(new Object[]{
                    product.getId(),
                    product.getName(),
                    product.getCategory(),
                    product.getPrice(),
                    product.getDescription()
            });
        }
    }

    private void saveProduct() {
        String name = nameField.getText().trim();
        String category = categoryField.getText().trim();
        String priceText = priceField.getText().trim();
        String description = descriptionArea.getText().trim();

        if (name.isEmpty() || category.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Price must be a number.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean created = productService.addProduct(name, category, price, description);
        if (created) {
            loadProducts();
            nameField.setText("");
            categoryField.setText("");
            priceField.setText("");
            descriptionArea.setText("");
            JOptionPane.showMessageDialog(this, "Product added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Could not add product.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedProduct() {
        int selectedRow = productTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int productId = (int) tableModel.getValueAt(selectedRow, 0);
        String productName = (String) tableModel.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete '" + productName + "'?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean deleted = productService.removeProduct(productId);
            if (deleted) {
                loadProducts();
                JOptionPane.showMessageDialog(this, "Product deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete product.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editSelectedProduct() {
        int selectedRow = productTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int productId = (int) tableModel.getValueAt(selectedRow, 0);
        String productName = (String) tableModel.getValueAt(selectedRow, 1);
        String productCategory = (String) tableModel.getValueAt(selectedRow, 2);
        double productPrice = (double) tableModel.getValueAt(selectedRow, 3);
        String productDescription = (String) tableModel.getValueAt(selectedRow, 4);

        showEditProductDialog(productId, productName, productCategory, productPrice, productDescription);
    }

    private void showEditProductDialog(int productId, String name, String category, double price, String description) {
        JDialog editDialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Edit Product", true);
        editDialog.setSize(500, 400);
        editDialog.setLocationRelativeTo(null);
        editDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        JPanel dialogPanel = new JPanel(new GridBagLayout());
        dialogPanel.setBorder(new EmptyBorder(16, 16, 16, 16));
        dialogPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Edit Product Details");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(34, 44, 82));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        dialogPanel.add(titleLabel, gbc);

        JLabel nameLabel = new JLabel("Product Name");
        JTextField editNameField = new JTextField(name, 25);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        dialogPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        dialogPanel.add(editNameField, gbc);

        JLabel categoryLabel = new JLabel("Category");
        JTextField editCategoryField = new JTextField(category, 25);
        gbc.gridx = 0;
        gbc.gridy = 2;
        dialogPanel.add(categoryLabel, gbc);
        gbc.gridx = 1;
        dialogPanel.add(editCategoryField, gbc);

        JLabel priceLabel = new JLabel("Price");
        JTextField editPriceField = new JTextField(String.valueOf(price), 25);
        gbc.gridx = 0;
        gbc.gridy = 3;
        dialogPanel.add(priceLabel, gbc);
        gbc.gridx = 1;
        dialogPanel.add(editPriceField, gbc);

        JLabel descriptionLabel = new JLabel("Description");
        JTextArea editDescriptionArea = new JTextArea(description, 4, 25);
        editDescriptionArea.setLineWrap(true);
        editDescriptionArea.setWrapStyleWord(true);
        JScrollPane descriptionScroll = new JScrollPane(editDescriptionArea);
        gbc.gridx = 0;
        gbc.gridy = 4;
        dialogPanel.add(descriptionLabel, gbc);
        gbc.gridx = 1;
        dialogPanel.add(descriptionScroll, gbc);

        JButton saveButton = new JButton("Save Changes");
        saveButton.setBackground(new Color(56, 142, 60));
        saveButton.setForeground(Color.WHITE);
        saveButton.addActionListener(e -> {
            String newName = editNameField.getText().trim();
            String newCategory = editCategoryField.getText().trim();
            String newPriceText = editPriceField.getText().trim();
            String newDescription = editDescriptionArea.getText().trim();

            if (newName.isEmpty() || newCategory.isEmpty() || newPriceText.isEmpty()) {
                JOptionPane.showMessageDialog(editDialog, "Please fill in all required fields.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double newPrice;
            try {
                newPrice = Double.parseDouble(newPriceText);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(editDialog, "Price must be a number.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }

            boolean updated = productService.updateProduct(productId, newName, newCategory, newPrice, newDescription);
            if (updated) {
                loadProducts();
                editDialog.dispose();
                JOptionPane.showMessageDialog(ProductsPanel.this, "Product updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(editDialog, "Failed to update product.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(211, 47, 47));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.addActionListener(e -> editDialog.dispose());

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        dialogPanel.add(buttonPanel, gbc);

        editDialog.add(dialogPanel);
        editDialog.setVisible(true);
    }
}
