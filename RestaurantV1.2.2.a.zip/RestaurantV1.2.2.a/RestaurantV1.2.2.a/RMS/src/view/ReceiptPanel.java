package view;

import model.Order;
import model.OrderItem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.DecimalFormat;

public class ReceiptPanel extends JPanel {

    private static final DecimalFormat CURRENCY_FORMAT = new DecimalFormat("#,##0.00");

    public ReceiptPanel(Order order, String transactionId, String paymentDate) {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(createHeader(), BorderLayout.NORTH);
        add(createReceiptContent(order, transactionId, paymentDate), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);
    }

    private JComponent createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);

        JLabel title = new JLabel("RECEIPT", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(34, 44, 82));
        title.setBorder(new EmptyBorder(0, 0, 20, 0));

        header.add(title, BorderLayout.CENTER);
        return header;
    }

    private JComponent createReceiptContent(Order order, String transactionId, String paymentDate) {
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(Color.WHITE);

        // Transaction ID
        content.add(createLabelPair("Transaction ID:", transactionId));
        content.add(Box.createVerticalStrut(10));

        // Date
        content.add(createLabelPair("Date:", paymentDate));
        content.add(Box.createVerticalStrut(10));

        // Order Number
        content.add(createLabelPair("Order Number:", order.getOrderNumber()));
        content.add(Box.createVerticalStrut(10));

        // Table (if assigned)
        if (order.getTableId() != null) {
            content.add(createLabelPair("Table:", "Table " + order.getTableId()));
            content.add(Box.createVerticalStrut(10));
        }

        // Items header
        content.add(createSectionHeader("Items"));
        content.add(Box.createVerticalStrut(5));

        // Items list
        for (OrderItem item : order.getItems()) {
            JPanel itemPanel = new JPanel(new BorderLayout());
            itemPanel.setBackground(Color.WHITE);
            itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

            JLabel itemName = new JLabel(item.getQuantity() + "x " + getProductName(item.getProductId()));
            itemName.setFont(new Font("Segoe UI", Font.PLAIN, 14));

            JLabel itemPrice = new JLabel("PHP " + CURRENCY_FORMAT.format(item.getTotalPrice()));
            itemPrice.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            itemPrice.setHorizontalAlignment(SwingConstants.RIGHT);

            itemPanel.add(itemName, BorderLayout.WEST);
            itemPanel.add(itemPrice, BorderLayout.EAST);

            content.add(itemPanel);
            content.add(Box.createVerticalStrut(2));
        }

        content.add(Box.createVerticalStrut(15));

        // Totals
        content.add(createTotalLine("Subtotal:", order.getSubtotal()));
        if (order.getTax() > 0) {
            content.add(createTotalLine("Tax:", order.getTax()));
        }
        if (order.getDiscount() > 0) {
            content.add(createTotalLine("Discount:", -order.getDiscount()));
        }
        content.add(createTotalLine("Total:", order.getTotal(), true));

        return content;
    }

    private JComponent createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(Color.WHITE);
        footer.setBorder(new EmptyBorder(20, 0, 0, 0));

        JLabel thankYou = new JLabel("Thank you for your business!", SwingConstants.CENTER);
        thankYou.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        thankYou.setForeground(new Color(102, 112, 131));

        footer.add(thankYou, BorderLayout.CENTER);
        return footer;
    }

    private JPanel createLabelPair(String label, String value) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));

        JLabel labelComp = new JLabel(label);
        labelComp.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JLabel valueComp = new JLabel(value);
        valueComp.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        panel.add(labelComp, BorderLayout.WEST);
        panel.add(valueComp, BorderLayout.EAST);

        return panel;
    }

    private JPanel createSectionHeader(String text) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);

        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(new Color(34, 44, 82));

        panel.add(label, BorderLayout.WEST);
        return panel;
    }

    private JPanel createTotalLine(String label, double amount) {
        return createTotalLine(label, amount, false);
    }

    private JPanel createTotalLine(String label, double amount, boolean bold) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));

        JLabel labelComp = new JLabel(label);
        if (bold) {
            labelComp.setFont(new Font("Segoe UI", Font.BOLD, 16));
        } else {
            labelComp.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        }

        JLabel amountComp = new JLabel("PHP " + CURRENCY_FORMAT.format(amount));
        if (bold) {
            amountComp.setFont(new Font("Segoe UI", Font.BOLD, 16));
        } else {
            amountComp.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        }
        amountComp.setHorizontalAlignment(SwingConstants.RIGHT);

        panel.add(labelComp, BorderLayout.WEST);
        panel.add(amountComp, BorderLayout.EAST);

        return panel;
    }

    // TODO: Replace with actual product name lookup
    private String getProductName(int productId) {
        // Placeholder - in real implementation, get from ProductDAO
        return "Product " + productId;
    }
}