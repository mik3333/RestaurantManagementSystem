package view;

import model.Order;
import service.OrderService;

import javax.swing.*;
import java.awt.*;

public class PaymentScreen extends JFrame {

    public interface PaymentCallback {
        void onPaymentSuccess(Order order, String transactionId, String paymentDate);
        void onPaymentFailed(String error);
    }

    private final Order order;
    private final PaymentCallback callback;
    private final OrderService orderService = new OrderService();

    public PaymentScreen(Order order, PaymentCallback callback) {
        this.order = order;
        this.callback = callback;

        setTitle("Payment");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(new Color(245, 245, 245));
        add(root);

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        card.setPreferredSize(new Dimension(220, 150));

        JLabel title = new JLabel("Payment");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JLabel totalLabel = new JLabel("Total: PHP " + String.format("%.2f", order.getTotal()));
        totalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton payBtn = new JButton("Pay");
        payBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        payBtn.setBackground(new Color(0, 153, 76));
        payBtn.setForeground(Color.WHITE);

        payBtn.addActionListener(e -> processPayment());

        card.add(title);
        card.add(Box.createVerticalStrut(10));
        card.add(totalLabel);
        card.add(Box.createVerticalStrut(15));
        card.add(payBtn);

        root.add(card);
        setVisible(true);
    }

    private void processPayment() {
        // For now, assume cash payment
        String paymentMethod = "Cash";

        OrderService.CheckoutResult result = orderService.checkout(order, paymentMethod, null); // TODO: Pass current user

        if (result.isSuccess()) {
            callback.onPaymentSuccess(order, result.getTransactionId(), result.getPaymentDate());
            dispose();
        } else {
            callback.onPaymentFailed(result.getMessage());
        }
    }
}