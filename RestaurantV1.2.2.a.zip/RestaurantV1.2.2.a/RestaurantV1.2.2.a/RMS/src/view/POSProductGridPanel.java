package view;

import controller.POSController;
import model.Product;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class POSProductGridPanel extends JPanel implements service.ProductService.ProductChangeListener {

    private final List<POSProductListener> listeners = new ArrayList<>();

    private POSController controller;
    private JPanel gridPanel;

    public POSProductGridPanel(POSController controller) {
        this.controller = controller;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        gridPanel = new JPanel(new GridLayout(3, 4, 12, 12));
        gridPanel.setBackground(Color.WHITE);
        gridPanel.setBorder(new EmptyBorder(12, 12, 12, 12));

        JScrollPane scroll = new JScrollPane(gridPanel);
        scroll.setBorder(null);
        add(scroll, BorderLayout.CENTER);

        refreshProductGrid();
    }

    public void refreshProductGrid() {
        gridPanel.removeAll();
        // Use filtered products if filter is active, otherwise use full catalog
        Map<String, Product> products = controller.getFilteredProducts();
        if (products == null || products.isEmpty()) {
            products = controller.getProductCatalog();
        }
        System.out.println("Refreshing product grid with " + (products != null ? products.size() : 0) + " products");
        if (products != null && !products.isEmpty()) {
            for (String product : products.keySet()) {
                gridPanel.add(createProductCard(product));
            }
        }
        gridPanel.revalidate();
        gridPanel.repaint();
    }

    @Override
    public void onProductListChanged() {
        SwingUtilities.invokeLater(this::refreshProductGrid);
    }

    private JPanel createProductCard(String productName) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(220, 224, 235), 1));

        JLabel imageLabel = new JLabel("[IMG]", SwingConstants.CENTER);
        imageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 36));
        imageLabel.setPreferredSize(new Dimension(120, 100));
        imageLabel.setMaximumSize(new Dimension(120, 100));
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel nameLabel = new JLabel(productName, SwingConstants.CENTER);
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        nameLabel.setForeground(new Color(50, 50, 50));
        nameLabel.setBorder(new EmptyBorder(8, 4, 8, 4));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(imageLabel);
        card.add(nameLabel);
        
        // Make card focusable and add keyboard/click support
        card.setFocusable(true);
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add both mouse and key listeners for full interactivity
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                notifyListeners(productName);
            }
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                card.setBorder(BorderFactory.createLineBorder(new Color(239, 109, 137), 2));
                card.setBackground(new Color(250, 250, 252));
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                card.setBorder(BorderFactory.createLineBorder(new Color(220, 224, 235), 1));
                card.setBackground(Color.WHITE);
            }
        });
        
        card.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt) {
                if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER || 
                    evt.getKeyCode() == java.awt.event.KeyEvent.VK_SPACE) {
                    notifyListeners(productName);
                }
            }
        });

        return card;
    }

    public void addProductListener(POSProductListener listener) {
        listeners.add(listener);
    }

    private void notifyListeners(String product) {
        for (POSProductListener listener : listeners) {
            listener.onProductSelected(product);
        }
    }

    public interface POSProductListener {
        void onProductSelected(String product);
    }
}
