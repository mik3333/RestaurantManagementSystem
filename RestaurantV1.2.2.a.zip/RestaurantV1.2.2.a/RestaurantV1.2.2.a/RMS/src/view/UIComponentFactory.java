package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Factory class for creating consistently styled UI components.
 * Use this to create buttons, labels, and other components with theme styling applied.
 * Simplifies UI creation and ensures consistency across panels.
 */
public class UIComponentFactory {

    /**
     * Create a primary action button (create, confirm, etc.)
     */
    public static JButton createPrimaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(ThemeConstants.BUTTON_FONT);
        button.setBackground(ThemeConstants.PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(120, ThemeConstants.BUTTON_HEIGHT));
        return button;
    }

    /**
     * Create a secondary action button (edit, confirm, etc.)
     */
    public static JButton createSecondaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(ThemeConstants.BUTTON_FONT);
        button.setBackground(ThemeConstants.SECONDARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(120, ThemeConstants.BUTTON_HEIGHT));
        return button;
    }

    /**
     * Create a danger action button (delete, remove, etc.)
     */
    public static JButton createDangerButton(String text) {
        JButton button = new JButton(text);
        button.setFont(ThemeConstants.BUTTON_FONT);
        button.setBackground(ThemeConstants.DANGER_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(120, ThemeConstants.BUTTON_HEIGHT));
        return button;
    }

    /**
     * Create a styled text field
     */
    public static JTextField createStyledTextField(int columns) {
        JTextField field = new JTextField(columns);
        field.setFont(ThemeConstants.TEXT_FIELD_FONT);
        field.setBorder(BorderFactory.createLineBorder(ThemeConstants.BORDER_COLOR));
        field.setPreferredSize(new Dimension(250, ThemeConstants.TEXT_FIELD_HEIGHT));
        return field;
    }

    /**
     * Create a styled password field
     */
    public static JPasswordField createStyledPasswordField(int columns) {
        JPasswordField field = new JPasswordField(columns);
        field.setFont(ThemeConstants.TEXT_FIELD_FONT);
        field.setBorder(BorderFactory.createLineBorder(ThemeConstants.BORDER_COLOR));
        field.setPreferredSize(new Dimension(250, ThemeConstants.TEXT_FIELD_HEIGHT));
        return field;
    }

    /**
     * Create a styled combo box
     */
    public static <T> JComboBox<T> createStyledComboBox(T[] items) {
        JComboBox<T> combo = new JComboBox<>(items);
        combo.setFont(ThemeConstants.TEXT_FIELD_FONT);
        combo.setPreferredSize(new Dimension(250, ThemeConstants.TEXT_FIELD_HEIGHT));
        return combo;
    }

    /**
     * Create a styled label
     */
    public static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(ThemeConstants.LABEL_FONT);
        label.setForeground(ThemeConstants.TEXT_PRIMARY);
        return label;
    }

    /**
     * Create a title label
     */
    public static JLabel createTitleLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(ThemeConstants.TITLE_FONT);
        label.setForeground(ThemeConstants.PRIMARY_COLOR);
        return label;
    }

    /**
     * Create a subtitle label
     */
    public static JLabel createSubtitleLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(ThemeConstants.SUBTITLE_FONT);
        label.setForeground(ThemeConstants.TEXT_PRIMARY);
        return label;
    }

    /**
     * Create a styled table with consistent appearance
     */
    public static JTable createStyledTable(Object[][] data, String[] columns) {
        JTable table = new JTable(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table.setRowHeight(ThemeConstants.TABLE_ROW_HEIGHT);
        table.setFont(ThemeConstants.LABEL_FONT);
        table.setSelectionBackground(new Color(230, 240, 250));
        table.setSelectionForeground(ThemeConstants.TEXT_PRIMARY);
        return table;
    }

    /**
     * Create a form panel with consistent styling
     */
    public static JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        return panel;
    }

    /**
     * Create a card panel (white background with padding)
     */
    public static JPanel createCardPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(ThemeConstants.CARD_BACKGROUND);
        panel.setBorder(new EmptyBorder(ThemeConstants.PADDING_MEDIUM, ThemeConstants.PADDING_MEDIUM, 
                                       ThemeConstants.PADDING_MEDIUM, ThemeConstants.PADDING_MEDIUM));
        return panel;
    }

    /**
     * Create a panel with title
     */
    public static JPanel createSectionPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(ThemeConstants.CARD_BACKGROUND);
        
        JLabel titleLabel = createSubtitleLabel(title);
        titleLabel.setBorder(new EmptyBorder(0, 0, ThemeConstants.PADDING_SMALL, 0));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        return panel;
    }
}
