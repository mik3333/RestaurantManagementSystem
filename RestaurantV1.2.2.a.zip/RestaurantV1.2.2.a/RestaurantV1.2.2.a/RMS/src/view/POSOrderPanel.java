package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class POSOrderPanel extends JPanel {

    private final DefaultTableModel tableModel;
    private final JTable orderTable;
    private final JSpinner removeQuantitySpinner;
    private final JButton removeButton;
    private final JButton removeAllButton;
    private final JButton removeAllItemsButton;
    private final List<OrderChangeListener> listeners = new ArrayList<>();

    public POSOrderPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(280, 440));
        setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, new Color(220, 224, 235)));

        String[] columnNames = {"SR#", "Product Name", "Qty", "Price", "Amount"};
        tableModel = new DefaultTableModel(columnNames, 0);
        orderTable = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        orderTable.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        orderTable.setRowHeight(24);
        orderTable.setBackground(Color.WHITE);
        orderTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane tableScroll = new JScrollPane(orderTable);
        tableScroll.setBorder(new EmptyBorder(8, 8, 8, 8));
        add(tableScroll, BorderLayout.CENTER);

        removeQuantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 99, 1));
        removeQuantitySpinner.setPreferredSize(new Dimension(60, 28));

        removeButton = new JButton("Remove");
        removeButton.setBackground(new Color(239, 109, 137));
        removeButton.setForeground(Color.WHITE);
        removeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        removeButton.setFocusPainted(false);
        removeButton.addActionListener(this::handleRemoveAction);

        removeAllButton = new JButton("Remove All");
        removeAllButton.setBackground(new Color(52, 152, 219));
        removeAllButton.setForeground(Color.WHITE);
        removeAllButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        removeAllButton.setFocusPainted(false);
        removeAllButton.addActionListener(this::handleRemoveAllAction);

        removeAllItemsButton = new JButton("Remove All Items");
        removeAllItemsButton.setBackground(new Color(155, 89, 182));
        removeAllItemsButton.setForeground(Color.WHITE);
        removeAllItemsButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        removeAllItemsButton.setFocusPainted(false);
        removeAllItemsButton.addActionListener(this::handleRemoveAllItemsAction);

        JPanel removePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 10));
        removePanel.setBackground(Color.WHITE);
        removePanel.add(new JLabel("Remove Qty:"));
        removePanel.add(removeQuantitySpinner);
        removePanel.add(removeButton);
        removePanel.add(removeAllButton);
        removePanel.add(removeAllItemsButton);

        add(removePanel, BorderLayout.SOUTH);
    }

    public void addOrderChangeListener(OrderChangeListener listener) {
        listeners.add(listener);
    }

    private void notifyItemRemoved(String productName, int quantityRemoved, boolean removedAll) {
        for (OrderChangeListener listener : listeners) {
            listener.onOrderItemRemoved(productName, quantityRemoved, removedAll);
        }
    }

    private void notifyOrderCleared() {
        for (OrderChangeListener listener : listeners) {
            listener.onOrderCleared();
        }
    }

    public void addItem(String productName, int quantity, double price) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String existingProduct = (String) tableModel.getValueAt(i, 1);
            if (existingProduct != null && existingProduct.equals(productName)) {
                int currentQty = ((Number) tableModel.getValueAt(i, 2)).intValue();
                int newQty = currentQty + quantity;
                tableModel.setValueAt(newQty, i, 2);
                tableModel.setValueAt(newQty * price, i, 4);
                return;
            }
        }
        double amount = quantity * price;
        Object[] row = {tableModel.getRowCount() + 1, productName, quantity, price, amount};
        tableModel.addRow(row);
    }

    public void updateQuantity(String productName, int newQuantity, double price) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String existingProduct = (String) tableModel.getValueAt(i, 1);
            if (existingProduct != null && existingProduct.equals(productName)) {
                if (newQuantity <= 0) {
                    tableModel.removeRow(i);
                } else {
                    tableModel.setValueAt(newQuantity, i, 2);
                    tableModel.setValueAt(newQuantity * price, i, 4);
                }
                refreshRowNumbers();
                return;
            }
        }
    }

    public void removeSelectedRow() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow < 0) {
            return;
        }

        String productName = (String) tableModel.getValueAt(selectedRow, 1);
        int currentQty = ((Number) tableModel.getValueAt(selectedRow, 2)).intValue();
        int removeQty = ((Number) removeQuantitySpinner.getValue()).intValue();
        removeQty = Math.max(1, Math.min(removeQty, currentQty));

        if (removeQty >= currentQty) {
            tableModel.removeRow(selectedRow);
            refreshRowNumbers();
            notifyItemRemoved(productName, removeQty, true);
        } else {
            int newQty = currentQty - removeQty;
            double price = ((Number) tableModel.getValueAt(selectedRow, 3)).doubleValue();
            tableModel.setValueAt(newQty, selectedRow, 2);
            tableModel.setValueAt(newQty * price, selectedRow, 4);
            notifyItemRemoved(productName, removeQty, false);
        }
    }

    private void handleRemoveAction(ActionEvent actionEvent) {
        removeSelectedRow();
    }

    private void handleRemoveAllAction(ActionEvent actionEvent) {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select an item to remove.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String productName = (String) tableModel.getValueAt(selectedRow, 1);
        int currentQty = ((Number) tableModel.getValueAt(selectedRow, 2)).intValue();

        int result = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to remove all " + currentQty + " quantity of '" + productName + "'?",
            "Confirm Removal",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (result == JOptionPane.YES_OPTION) {
            tableModel.removeRow(selectedRow);
            refreshRowNumbers();
            notifyItemRemoved(productName, currentQty, true);
        }
    }

    private void handleRemoveAllItemsAction(ActionEvent actionEvent) {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Order is already empty.", "No Items", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int result = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to remove all items from the order?",
            "Confirm Clear Order",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (result == JOptionPane.YES_OPTION) {
            tableModel.setRowCount(0);
            notifyOrderCleared();
        }
    }

    private void refreshRowNumbers() {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.setValueAt(i + 1, i, 0);
        }
    }

    public void clearOrder() {
        tableModel.setRowCount(0);
    }

    public double getTotalAmount() {
        double total = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Object amountObj = tableModel.getValueAt(i, 4);
            if (amountObj instanceof Number) {
                total += ((Number) amountObj).doubleValue();
            }
        }
        return total;
    }

    public interface OrderChangeListener {
        void onOrderItemRemoved(String productName, int quantityRemoved, boolean removedAll);
        void onOrderCleared();
    }
}
