package view;

import model.User;
import service.StaffService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UsersPanel extends JPanel {

    private final StaffService staffService = new StaffService();
    private final User currentUser;
    private DefaultTableModel tableModel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleCombo;
    private JTable userTable;
    private JPanel formPanel;
    private JButton createButton;
    private JButton deleteButton;
    private JButton editRoleButton;

    public UsersPanel(User currentUser) {
        this.currentUser = currentUser;
        setLayout(new BorderLayout(ThemeConstants.PADDING_MEDIUM, ThemeConstants.PADDING_MEDIUM));
        setBackground(ThemeConstants.BACKGROUND_COLOR);
        setBorder(new EmptyBorder(ThemeConstants.PADDING_LARGE, ThemeConstants.PADDING_LARGE, 
                                 ThemeConstants.PADDING_LARGE, ThemeConstants.PADDING_LARGE));

        JLabel title = UIComponentFactory.createTitleLabel("Staff & Manager Accounts");
        add(title, BorderLayout.NORTH);
        add(createContent(), BorderLayout.CENTER);
        
        if (staffService.canManageStaff(currentUser)) {
            add(createForm(), BorderLayout.SOUTH);
        }

        loadUsers();
    }

    private JComponent createContent() {
        String[] columns = {"Username", "Role"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        userTable = new JTable(tableModel);
        userTable.setRowHeight(ThemeConstants.TABLE_ROW_HEIGHT);
        userTable.setFont(ThemeConstants.LABEL_FONT);
        userTable.setSelectionBackground(new Color(230, 240, 250));
        userTable.setSelectionForeground(ThemeConstants.TEXT_PRIMARY);
        userTable.setBackground(ThemeConstants.CARD_BACKGROUND);
        userTable.setGridColor(ThemeConstants.BORDER_COLOR);

        // Style header
        userTable.getTableHeader().setBackground(ThemeConstants.TABLE_HEADER_BG);
        userTable.getTableHeader().setForeground(ThemeConstants.TEXT_PRIMARY);
        userTable.getTableHeader().setFont(ThemeConstants.SUBTITLE_FONT);
        userTable.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, ThemeConstants.BORDER_COLOR));

        JScrollPane scrollPane = new JScrollPane(userTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(ThemeConstants.BORDER_COLOR));
        return scrollPane;
    }

    private JComponent createForm() {
        formPanel = UIComponentFactory.createFormPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = ThemeConstants.FORM_INSETS;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username field
        JLabel usernameLabel = UIComponentFactory.createLabel("Username");
        usernameField = UIComponentFactory.createStyledTextField(18);

        // Password field
        JLabel passwordLabel = UIComponentFactory.createLabel("Password");
        passwordField = UIComponentFactory.createStyledPasswordField(18);

        // Role field
        JLabel roleLabel = UIComponentFactory.createLabel("Role");
        String[] availableRoles = staffService.getAvailableRolesToCreate(currentUser);
        roleCombo = UIComponentFactory.createStyledComboBox(availableRoles);

        // Create button
        createButton = UIComponentFactory.createPrimaryButton("Create Account");
        createButton.addActionListener(e -> saveUser());

        // Delete button (only for Admin)
        deleteButton = UIComponentFactory.createDangerButton("Delete Selected");
        deleteButton.addActionListener(e -> deleteSelectedUser());
        deleteButton.setEnabled(staffService.isAdmin(currentUser));

        // Edit role button (only for Admin)
        editRoleButton = UIComponentFactory.createSecondaryButton("Edit Role");
        editRoleButton.addActionListener(e -> editSelectedUserRole());
        editRoleButton.setEnabled(staffService.isAdmin(currentUser));

        // Add form fields
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        formPanel.add(usernameField, gbc);
        gbc.gridwidth = 1;

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        formPanel.add(passwordField, gbc);
        gbc.gridwidth = 1;

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(roleLabel, gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        formPanel.add(roleCombo, gbc);
        gbc.gridwidth = 1;

        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, ThemeConstants.PADDING_SMALL, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(createButton);
        
        if (staffService.isAdmin(currentUser)) {
            buttonPanel.add(deleteButton);
            buttonPanel.add(editRoleButton);
        }
        
        formPanel.add(buttonPanel, gbc);

        return formPanel;
    }

    private void loadUsers() {
        tableModel.setRowCount(0);
        List<User> users = staffService.getAllStaff();
        for (User user : users) {
            tableModel.addRow(new Object[]{user.getUsername(), user.getRole()});
        }
    }

    private void saveUser() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        Object selectedRole = roleCombo.getSelectedItem();
        
        if (selectedRole == null) {
            JOptionPane.showMessageDialog(this, "Please select a role.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String role = (String) selectedRole;

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (staffService.staffExists(username)) {
            JOptionPane.showMessageDialog(this, "That username is already taken.", "Duplicate User", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!staffService.canCreateRole(currentUser, role)) {
            JOptionPane.showMessageDialog(this, "As a " + currentUser.getRole() + ", you can only create " + String.join("/", staffService.getAvailableRolesToCreate(currentUser)) + " accounts.", "Permission Denied", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean created = staffService.createStaffAccount(username, password, role);
        if (created) {
            loadUsers();
            usernameField.setText("");
            passwordField.setText("");
            JOptionPane.showMessageDialog(this, "Account created successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Could not create account. Check the role or database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedUser() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a user to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String username = (String) tableModel.getValueAt(selectedRow, 0);
        if (staffService.isProtectedAccount(username)) {
            JOptionPane.showMessageDialog(this, "Cannot delete the admin account.", "Permission Denied", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete '" + username + "'?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean deleted = staffService.deleteStaffAccount(username);
            if (deleted) {
                loadUsers();
                JOptionPane.showMessageDialog(this, "Account deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete account.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editSelectedUserRole() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a user to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String username = (String) tableModel.getValueAt(selectedRow, 0);
        if (staffService.isProtectedAccount(username)) {
            JOptionPane.showMessageDialog(this, "Cannot edit the admin account.", "Permission Denied", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String currentRole = (String) tableModel.getValueAt(selectedRow, 1);
        String[] roles = {"Manager", "Cashier"};
        String newRole = (String) JOptionPane.showInputDialog(this, "Select new role for " + username + ":", "Edit Role", JOptionPane.QUESTION_MESSAGE, null, roles, currentRole);

        if (newRole != null) {
            boolean updated = staffService.updateStaffRole(username, newRole);
            if (updated) {
                loadUsers();
                JOptionPane.showMessageDialog(this, "Role updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update role.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
