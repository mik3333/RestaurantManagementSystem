package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import service.ProductService;

public class POSCategoryPanel extends JPanel {

    private final List<POSCategoryListener> listeners = new ArrayList<>();

    public POSCategoryPanel() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(45, 55, 95));
        setPreferredSize(new Dimension(120, 400));
        setBorder(new EmptyBorder(12, 12, 12, 12));

        // Load categories dynamically from product service
        Set<String> categories = loadCategoriesFromService();
        
        // Add "All Categories" first
        add(createCategoryButton("All Categories"));
        add(Box.createVerticalStrut(8));
        
        // Add dynamically loaded categories
        for (String cat : categories) {
            add(createCategoryButton(cat));
            add(Box.createVerticalStrut(8));
        }

        add(Box.createVerticalGlue());
    }

    private Set<String> loadCategoriesFromService() {
        Set<String> categories = new TreeSet<>();
        try {
            ProductService productService = new ProductService();
            List<model.Product> products = productService.getAllProducts();
            if (products != null && !products.isEmpty()) {
                for (model.Product p : products) {
                    if (p.getCategory() != null && !p.getCategory().trim().isEmpty()) {
                        categories.add(p.getCategory());
                    }
                }
            }
            if (categories.isEmpty()) {
                // If no categories found, use defaults
                categories.add("Drinks");
                categories.add("Burger");
                categories.add("Pizza");
                categories.add("BBQ");
            }
        } catch (Exception e) {
            // Fallback to default categories if error
            System.err.println("Error loading categories: " + e.getMessage());
            e.printStackTrace();
            categories.add("Drinks");
            categories.add("Burger");
            categories.add("Pizza");
            categories.add("BBQ");
        }
        return categories;
    }

    private JButton createCategoryButton(String category) {
        JButton btn = new JButton(category);
        btn.setBackground(new Color(45, 55, 95));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> notifyListeners(category));
        return btn;
    }

    public void addCategoryListener(POSCategoryListener listener) {
        listeners.add(listener);
    }

    private void notifyListeners(String category) {
        for (POSCategoryListener listener : listeners) {
            listener.onCategorySelected(category);
        }
    }

    public interface POSCategoryListener {
        void onCategorySelected(String category);
    }
}
