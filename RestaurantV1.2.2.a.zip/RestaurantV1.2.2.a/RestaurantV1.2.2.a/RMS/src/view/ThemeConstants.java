package view;

import java.awt.*;

/**
 * Centralized theme constants for consistent UI styling across the application.
 * Update colors and fonts here to maintain consistency throughout the app.
 */
public class ThemeConstants {

    // Color Palette
    public static final Color PRIMARY_COLOR = new Color(215, 72, 120);      // Pink/Magenta
    public static final Color SECONDARY_COLOR = new Color(56, 142, 60);     // Green
    public static final Color DANGER_COLOR = new Color(211, 47, 47);        // Red
    public static final Color BACKGROUND_COLOR = new Color(244, 248, 253);  // Light Blue-Gray
    public static final Color CARD_BACKGROUND = Color.WHITE;
    public static final Color TEXT_PRIMARY = new Color(34, 44, 82);         // Dark Blue
    public static final Color TEXT_SECONDARY = new Color(102, 112, 131);    // Gray
    public static final Color BORDER_COLOR = new Color(221, 224, 235);      // Light Gray-Blue
    public static final Color TABLE_HEADER_BG = new Color(245, 245, 245);
    public static final Color TABLE_ALTERNATE_ROW = new Color(248, 250, 253);

    // Fonts
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font SUBTITLE_FONT = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font TEXT_FIELD_FONT = new Font("Segoe UI", Font.PLAIN, 12);

    // Spacing
    public static final int PADDING_LARGE = 16;
    public static final int PADDING_MEDIUM = 12;
    public static final int PADDING_SMALL = 8;
    public static final int CORNER_RADIUS = 4;

    // Component Sizes
    public static final int TABLE_ROW_HEIGHT = 32;
    public static final int BUTTON_HEIGHT = 32;
    public static final int TEXT_FIELD_HEIGHT = 28;

    // Insets
    public static final Insets FORM_INSETS = new Insets(PADDING_SMALL, PADDING_SMALL, PADDING_SMALL, PADDING_SMALL);
}
