package view;

import model.Order;
import model.OrderItem;
import service.OrderService;
import database.OrderDAO;
import database.ProductDAO;
import model.Product;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.List;

public class ReportsPanel extends JPanel {

    private final OrderService orderService = new OrderService();
    private final ProductDAO productDAO = new ProductDAO();
    private final DecimalFormat currencyFormat = new DecimalFormat("#,##0.00");
    private JTable reportsTable;
    private DefaultTableModel tableModel;

    public ReportsPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 242, 247));
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(createHeader(), BorderLayout.NORTH);
        add(createContent(), BorderLayout.CENTER);
    }

    private JComponent createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("Transaction Reports");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(39, 56, 103));

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(39, 56, 103));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        refreshBtn.addActionListener(e -> loadReports());

        header.add(title, BorderLayout.WEST);
        header.add(refreshBtn, BorderLayout.EAST);

        return header;
    }

    private JComponent createContent() {
        JPanel content = new JPanel(new BorderLayout());
        content.setOpaque(false);

        // Table model
        String[] columns = {"Date", "Order #", "Transaction ID", "Items", "Subtotal", "Tax", "Discount", "Total", "Payment Method"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        reportsTable = new JTable(tableModel);
        reportsTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        reportsTable.setRowHeight(25);
        reportsTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        reportsTable.getTableHeader().setBackground(new Color(39, 56, 103));
        reportsTable.getTableHeader().setForeground(Color.WHITE);
        reportsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Double-click to view receipt
        reportsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    viewSelectedReceipt();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(reportsTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);

        JButton viewReceiptBtn = new JButton("View Receipt");
        viewReceiptBtn.addActionListener(e -> viewSelectedReceipt());

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.addActionListener(e -> deleteSelectedOrder());

        buttonPanel.add(viewReceiptBtn);
        buttonPanel.add(deleteBtn);

        content.add(scrollPane, BorderLayout.CENTER);
        content.add(buttonPanel, BorderLayout.SOUTH);

        loadReports();
        return content;
    }

    private void loadReports() {
        tableModel.setRowCount(0);
        List<Order> orders = orderService.getCompletedOrders();

        for (Order order : orders) {
            OrderDAO.PaymentInfo payment = orderService.getPaymentInfo(order.getId());
            String paymentMethod = (payment != null) ? payment.getPaymentMethod() : "N/A";

            // Count items
            int itemCount = order.getItems().size();

            tableModel.addRow(new Object[]{
                    formatDate(order.getCreatedAt()),
                    order.getOrderNumber(),
                    (payment != null) ? payment.getTransactionReference() : "N/A",
                    itemCount,
                    "PHP " + currencyFormat.format(order.getSubtotal()),
                    "PHP " + currencyFormat.format(order.getTax()),
                    "PHP " + currencyFormat.format(order.getDiscount()),
                    "PHP " + currencyFormat.format(order.getTotal()),
                    paymentMethod
            });
        }
    }

    private void viewSelectedReceipt() {
        int selectedRow = reportsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a transaction to view.", 
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<Order> orders = orderService.getCompletedOrders();
        if (selectedRow >= orders.size()) return;

        Order order = orders.get(selectedRow);
        OrderDAO.PaymentInfo payment = orderService.getPaymentInfo(order.getId());

        if (payment == null) {
            JOptionPane.showMessageDialog(this, "Payment information not found.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Show receipt in a dialog
        showReceiptDialog(order, payment);
    }

    private void showReceiptDialog(Order order, OrderDAO.PaymentInfo payment) {
        JDialog dialog = new JDialog((Frame) null, "Receipt - " + order.getOrderNumber(), true);
        dialog.setSize(450, 600);
        dialog.setLocationRelativeTo(this);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(new EmptyBorder(20, 20, 20, 20));
        content.setBackground(Color.WHITE);

        // Header
        JLabel receiptTitle = new JLabel("RECEIPT", SwingConstants.CENTER);
        receiptTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        receiptTitle.setForeground(new Color(34, 44, 82));
        receiptTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        content.add(receiptTitle);
        content.add(Box.createVerticalStrut(20));

        // Transaction details
        content.add(createDetailRow("Transaction ID:", payment.getTransactionReference()));
        content.add(createDetailRow("Date:", formatDate(payment.getPaidAt())));
        content.add(createDetailRow("Order Number:", order.getOrderNumber()));
        content.add(createDetailRow("Payment Method:", payment.getPaymentMethod()));
        content.add(Box.createVerticalStrut(15));

        // Items section
        JLabel itemsHeader = new JLabel("Items");
        itemsHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        itemsHeader.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(itemsHeader);
        content.add(Box.createVerticalStrut(5));

        for (OrderItem item : order.getItems()) {
            JPanel itemRow = new JPanel(new BorderLayout());
            itemRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
            itemRow.setOpaque(false);

            JLabel itemName = new JLabel(item.getQuantity() + "x " + getProductName(item.getProductId()));
            itemName.setFont(new Font("Segoe UI", Font.PLAIN, 13));

            JLabel itemPrice = new JLabel("PHP " + currencyFormat.format(item.getTotalPrice()));
            itemPrice.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            itemPrice.setHorizontalAlignment(SwingConstants.RIGHT);

            itemRow.add(itemName, BorderLayout.WEST);
            itemRow.add(itemPrice, BorderLayout.EAST);
            content.add(itemRow);
        }

        content.add(Box.createVerticalStrut(15));

        // Totals
        content.add(createTotalRow("Subtotal:", order.getSubtotal()));
        if (order.getTax() > 0) {
            content.add(createTotalRow("Tax:", order.getTax()));
        }
        if (order.getDiscount() > 0) {
            content.add(createTotalRow("Discount:", -order.getDiscount()));
        }
        content.add(createTotalRow("Total:", order.getTotal(), true));

        content.add(Box.createVerticalStrut(15));

        // Payment details
        content.add(createDetailRow("Amount Paid:", "PHP " + currencyFormat.format(payment.getAmountPaid())));
        content.add(createDetailRow("Change:", "PHP " + currencyFormat.format(payment.getChangeAmount())));

        // Close button
        JButton closeBtn = new JButton("Close");
        closeBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        closeBtn.setMaximumSize(new Dimension(100, 30));
        closeBtn.addActionListener(e -> dialog.dispose());
        content.add(Box.createVerticalStrut(20));
        content.add(closeBtn);

        dialog.add(new JScrollPane(content));
        dialog.setVisible(true);
    }

    private JPanel createDetailRow(String label, String value) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        labelComponent.setForeground(Color.GRAY);

        JLabel valueComponent = new JLabel(value);
        valueComponent.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        valueComponent.setHorizontalAlignment(SwingConstants.RIGHT);

        row.add(labelComponent, BorderLayout.WEST);
        row.add(valueComponent, BorderLayout.EAST);
        return row;
    }

    private JPanel createTotalRow(String label, double amount) {
        return createTotalRow(label, amount, false);
    }

    private JPanel createTotalRow(String label, double amount, boolean isTotal) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(new Font("Segoe UI", isTotal ? Font.BOLD : Font.PLAIN, isTotal ? 16 : 13));
        labelComponent.setForeground(isTotal ? Color.BLACK : Color.GRAY);

        JLabel valueComponent = new JLabel("PHP " + currencyFormat.format(amount));
        valueComponent.setFont(new Font("Segoe UI", isTotal ? Font.BOLD : Font.PLAIN, isTotal ? 16 : 13));
        valueComponent.setHorizontalAlignment(SwingConstants.RIGHT);

        row.add(labelComponent, BorderLayout.WEST);
        row.add(valueComponent, BorderLayout.EAST);
        return row;
    }

    private void deleteSelectedOrder() {
        int selectedRow = reportsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a transaction to delete.", 
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to delete this transaction?", 
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // For now, just show a message - actual deletion would require more implementation
            JOptionPane.showMessageDialog(this, "Delete functionality not fully implemented.", 
                    "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private String formatDate(String dateStr) {
        if (dateStr == null) return "N/A";
        try {
            // SQLite returns date in format like "2026-04-26 14:30:00"
            return dateStr.substring(0, 19).replace(" ", " ");
        } catch (Exception e) {
            return dateStr;
        }
    }

    private String getProductName(int productId) {
        Product product = productDAO.findById(productId);
        return (product != null) ? product.getName() : "Product #" + productId;
    }
}