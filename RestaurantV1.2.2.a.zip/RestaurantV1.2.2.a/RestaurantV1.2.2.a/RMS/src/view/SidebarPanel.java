package view;

import model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class SidebarPanel extends JPanel {

    private final SidebarListener listener;
    private final User currentUser;

    public SidebarPanel(SidebarListener listener, User currentUser) {
        this.listener = listener;
        this.currentUser = currentUser;

        setLayout(new BorderLayout());
        setBackground(new Color(34, 44, 82));
        setPreferredSize(new Dimension(220, 0));

        add(createBrandPanel(), BorderLayout.NORTH);
        add(createMenuPanel(), BorderLayout.CENTER);
        add(createFooterPanel(), BorderLayout.SOUTH);
    }

    private JComponent createBrandPanel() {
        JPanel brand = new JPanel();
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));
        brand.setBackground(new Color(34, 44, 82));
        brand.setBorder(new EmptyBorder(24, 20, 24, 20));

        JLabel icon = new JLabel("[LOGO]", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        icon.setForeground(Color.WHITE);
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("POS System", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(new EmptyBorder(12, 0, 0, 0));

        brand.add(icon);
        brand.add(title);
        return brand;
    }

    private JComponent createMenuPanel() {
        JPanel menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBackground(new Color(34, 44, 82));
        menu.setBorder(new EmptyBorder(10, 0, 10, 0));

        // Always show Home
        addMenuButton(menu, "Home");

        // Products - show for Admin/Manager
        if (canAccessProducts()) {
            addMenuButton(menu, "Products");
        }

        // Tables - show for Admin/Manager/Cashier
        if (canAccessTables()) {
            addMenuButton(menu, "Tables");
        }

        // Staff - show for Admin/Manager
        if (canAccessStaff()) {
            addMenuButton(menu, "Staff");
        }

        // POS - show for Admin/Manager/Cashier
        if (canAccessPOS()) {
            addMenuButton(menu, "POS");
        }

        // Kitchen - show for Admin/Manager/Cashier
        if (canAccessKitchen()) {
            addMenuButton(menu, "Kitchen");
        }

        // Reports - show for Admin/Manager/Cashier
        if (canAccessReports()) {
            addMenuButton(menu, "Reports");
        }

        return menu;
    }

    private void addMenuButton(JPanel menu, String text) {
        JButton btn = createMenuButton(text);
        menu.add(btn);
        menu.add(Box.createVerticalStrut(8));
    }

    private boolean canAccessCategories() {
        return currentUser.getRole().equals("Admin") || currentUser.getRole().equals("Manager");
    }

    private boolean canAccessProducts() {
        return currentUser.getRole().equals("Admin") || currentUser.getRole().equals("Manager");
    }

    private boolean canAccessTables() {
        return currentUser.getRole().equals("Admin") || currentUser.getRole().equals("Manager") || currentUser.getRole().equals("Cashier");
    }

    private boolean canAccessStaff() {
        return currentUser.getRole().equals("Admin") || currentUser.getRole().equals("Manager");
    }

    private boolean canAccessPOS() {
        return currentUser.getRole().equals("Admin") || currentUser.getRole().equals("Manager") || currentUser.getRole().equals("Cashier");
    }

    private boolean canAccessKitchen() {
        return currentUser.getRole().equals("Admin") || currentUser.getRole().equals("Manager") || currentUser.getRole().equals("Cashier");
    }

    private boolean canAccessReports() {
        return currentUser.getRole().equals("Admin") || currentUser.getRole().equals("Manager") || currentUser.getRole().equals("Cashier");
    }

    private boolean canAccessSettings() {
        return currentUser.getRole().equals("Admin");
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(34, 44, 82));
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> listener.onMenuSelected(text));
        return btn;
    }

    private JComponent createFooterPanel() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(34, 44, 82));
        footer.setBorder(new EmptyBorder(16, 20, 20, 20));

        JButton exitBtn = new JButton("Exit");
        exitBtn.setFocusPainted(false);
        exitBtn.setBackground(new Color(211, 47, 47));
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setOpaque(true);
        exitBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        exitBtn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        exitBtn.addActionListener(e -> System.exit(0));

        footer.add(exitBtn, BorderLayout.SOUTH);
        return footer;
    }
}