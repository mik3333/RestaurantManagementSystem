package view;

import controller.POSController;
import model.Order;
import model.OrderItem;
import model.Table;
import service.TableService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class POSPanel extends JPanel implements POSOrderPanel.OrderChangeListener {

    private final POSController posController;
    private final POSOrderPanel orderPanel;
    private JLabel totalLabel;
    private JSpinner quantitySpinner;
    private JLabel quantityLabel;
    private POSProductGridPanel productGridPanel;

    public POSPanel() {
        this.posController = new POSController();
        this.orderPanel = new POSOrderPanel();

        setLayout(new BorderLayout());
        setBackground(new Color(240, 242, 247));

        add(createTopToolbar(), BorderLayout.NORTH);
        add(createMainContent(), BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);
    }

    private JComponent createTopToolbar() {
        POSToolbarPanel toolbar = new POSToolbarPanel();
        toolbar.addToolbarListener(action -> handleToolbarAction(action));
        return toolbar;
    }

    private JComponent createMainContent() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Top section with search and quantity input
        JPanel topSection = new JPanel(new BorderLayout());
        topSection.setOpaque(false);
        
        POSSearchPanel searchPanel = new POSSearchPanel();
        searchPanel.addSearchListener(query -> handleSearch(query));
        topSection.add(searchPanel, BorderLayout.NORTH);
        
        // Quantity input panel
        topSection.add(createQuantityPanel(), BorderLayout.CENTER);
        
        mainPanel.add(topSection, BorderLayout.NORTH);

        mainPanel.add(createContentArea(), BorderLayout.CENTER);

        return mainPanel;
    }

    private JComponent createQuantityPanel() {
        JPanel quantityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        quantityPanel.setOpaque(false);
        quantityPanel.setBorder(new EmptyBorder(8, 0, 8, 0));

        JLabel qtyLabel = new JLabel("Enter Quantity:");
        qtyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        qtyLabel.setForeground(new Color(50, 50, 50));

        SpinnerModel spinnerModel = new SpinnerNumberModel(1, 1, 99, 1);
        quantitySpinner = new JSpinner(spinnerModel);
        quantitySpinner.setPreferredSize(new Dimension(60, 28));
        quantitySpinner.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        quantityLabel = new JLabel("1");
        quantityLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        quantityLabel.setForeground(new Color(239, 109, 137));

        quantityPanel.add(qtyLabel);
        quantityPanel.add(quantitySpinner);
        quantityPanel.add(quantityLabel);

        return quantityPanel;
    }

    private JComponent createContentArea() {
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(Color.WHITE);

        POSCategoryPanel categoryPanel = new POSCategoryPanel();
        categoryPanel.addCategoryListener(category -> handleCategorySelection(category));

        productGridPanel = new POSProductGridPanel(posController);
        productGridPanel.addProductListener(product -> handleProductSelection(product));
        orderPanel.addOrderChangeListener(this);

        contentPanel.add(categoryPanel, BorderLayout.WEST);
        contentPanel.add(productGridPanel, BorderLayout.CENTER);
        contentPanel.add(orderPanel, BorderLayout.EAST);

        return contentPanel;
    }

    private JComponent createBottomPanel() {
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(new Color(240, 242, 247));
        bottomPanel.setBorder(new EmptyBorder(12, 16, 12, 16));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        buttonPanel.setOpaque(false);

        JButton checkOutBtn = new JButton("Check Out");
        checkOutBtn.setBackground(new Color(239, 109, 137));
        checkOutBtn.setForeground(Color.WHITE);
        checkOutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        checkOutBtn.setFocusPainted(false);
        checkOutBtn.setPreferredSize(new Dimension(100, 36));
        checkOutBtn.addActionListener(e -> handleCheckout());

        totalLabel = new JLabel("Total : PHP 0.00");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        totalLabel.setForeground(new Color(50, 50, 50));

        buttonPanel.add(checkOutBtn);
        buttonPanel.add(totalLabel);

        bottomPanel.add(buttonPanel, BorderLayout.EAST);

        return bottomPanel;
    }

    private void handleToolbarAction(String action) {
        switch (action) {
            case "New":
                posController.clearOrder();
                orderPanel.clearOrder();
                updateTotal();
                break;
            case "Hold":
                JOptionPane.showMessageDialog(this, "Order on Hold");
                break;
            case "KOT": // Kitchen Order Ticket - send order to kitchen
                handleKOT();
                break;
            case "Dine In":
                JOptionPane.showMessageDialog(this, "Dine In Mode");
                break;
        }
    }

    // KOT (Kitchen Order Ticket) - sends current order to the kitchen
    private void handleKOT() {
        POSController.KitchenTicket ticket = posController.sendToKitchen();
        if (ticket != null) {
            JOptionPane.showMessageDialog(this, "Order sent to Kitchen\nTicket: " + ticket.getTicketId());
            orderPanel.clearOrder();
        } else {
            JOptionPane.showMessageDialog(this, "Order is empty. Add items before sending to kitchen.");
        }
    }

    private void handleCategorySelection(String category) {
        try {
            // Filter products by category
            posController.filterByCategory(category);
            refreshProductGrid();
        } catch (Exception e) {
            System.err.println("Error selecting category: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleProductSelection(String product) {
        try {
            // Get quantity from spinner
            int quantity = (Integer) quantitySpinner.getValue();
            if (quantity <= 0) {
                quantity = 1;
            }
            
            // Add product to order with quantity
            model.Product prod = posController.getProduct(product);
            if (prod != null) {
                posController.addToOrder(product, quantity);
                orderPanel.addItem(product, quantity, prod.getPrice());
                updateTotal();
                
                // Reset quantity spinner to 1 after adding
                quantitySpinner.setValue(1);
            } else {
                System.err.println("Product not found: " + product);
            }
        } catch (Exception e) {
            System.err.println("Error selecting product: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onOrderItemRemoved(String productName, int quantityRemoved, boolean removedAll) {
        handleRemoveOrderItem(productName, quantityRemoved, removedAll);
    }

    @Override
    public void onOrderCleared() {
        handleOrderCleared();
    }

    private void handleSearch(String query) {
        try {
            // Search for products - filter by keyword
            posController.searchProducts(query);
            refreshProductGrid();
        } catch (Exception e) {
            System.err.println("Error searching products: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void refreshProductGrid() {
        try {
            if (productGridPanel != null) {
                productGridPanel.refreshProductGrid();
            } else {
                System.err.println("Product grid panel is null");
            }
        } catch (Exception e) {
            System.err.println("Error refreshing product grid: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleCheckout() {
        double total = posController.calculateTotal();
        if (total <= 0) {
            JOptionPane.showMessageDialog(this, "Order is empty");
            return;
        }

        // Show table selection dialog
        Integer selectedTableId = showTableSelectionDialog();
        if (selectedTableId == null) {
            return; // User cancelled
        }

        // Create order object
        List<OrderItem> items = posController.getOrderItems();
        Order order = new Order(
            generateOrderNumber(),
            1, // TODO: Get current user ID
            selectedTableId,
            items,
            posController.calculateSubtotal(),
            posController.calculateTax(),
            0.0, // discount
            total
        );

        // Show payment screen
        PaymentScreen paymentScreen = new PaymentScreen(order, new PaymentScreen.PaymentCallback() {
            @Override
            public void onPaymentSuccess(Order completedOrder, String transactionId, String paymentDate) {
                showReceipt(completedOrder, transactionId, paymentDate);
                posController.clearOrder();
            }

            @Override
            public void onPaymentFailed(String error) {
                JOptionPane.showMessageDialog(POSPanel.this, "Payment failed: " + error, "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private Integer showTableSelectionDialog() {
        TableService tableService = new TableService();
        List<Table> availableTables = tableService.getAvailableTables();

        if (availableTables.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No available tables. Please select a table anyway or cancel.");
            // Show all tables
            availableTables = tableService.getAllTables();
        }

        String[] tableOptions = new String[availableTables.size() + 1];
        tableOptions[0] = "No table (Takeaway)";
        for (int i = 0; i < availableTables.size(); i++) {
            Table table = availableTables.get(i);
            tableOptions[i + 1] = "Table " + table.getId() + " (" + table.getSeats() + " seats) - " + table.getStatus();
        }

        String selected = (String) JOptionPane.showInputDialog(
            this,
            "Select a table for this order:",
            "Table Selection",
            JOptionPane.QUESTION_MESSAGE,
            null,
            tableOptions,
            tableOptions[0]
        );

        if (selected == null) {
            return null; // Cancelled
        }

        if (selected.equals("No table (Takeaway)")) {
            return null;
        }

        // Extract table ID from selection
        for (Table table : availableTables) {
            if (selected.startsWith("Table " + table.getId())) {
                return table.getId();
            }
        }

        return null;
    }

    private void showReceipt(Order order, String transactionId, String paymentDate) {
        JDialog receiptDialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "Receipt", true);
        receiptDialog.setSize(400, 600);
        receiptDialog.setLocationRelativeTo(null);
        receiptDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        ReceiptPanel receiptPanel = new ReceiptPanel(order, transactionId, paymentDate);
        receiptDialog.add(receiptPanel);
        receiptDialog.setVisible(true);
    }

    private String generateOrderNumber() {
        // Simple order number generation
        return "ORD-" + System.currentTimeMillis();
    }

    private void handleRemoveOrderItem(String productName) {
        posController.removeFromOrder(productName);
        updateTotal();
    }

    private void updateTotal() {
        double total = posController.calculateTotal();
        totalLabel.setText("Total : PHP " + String.format("%,.2f", total));
    }
}
