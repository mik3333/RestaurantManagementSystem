package view;

import model.Table;
import model.User;
import service.TableService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TablesPanel extends JPanel {

    private final TableService tableService = new TableService();
    private final User currentUser;
    private DefaultTableModel tableModel;
    private JTable tablesTable;

    public TablesPanel(User currentUser) {
        this.currentUser = currentUser;
        setLayout(new BorderLayout(12, 12));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(16, 16, 16, 16));

        JLabel title = new JLabel("Table Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(34, 44, 82));

        add(title, BorderLayout.NORTH);
        add(createTablesTable(), BorderLayout.CENTER);
        add(createControls(), BorderLayout.SOUTH);

        loadTables();
    }

    private JComponent createTablesTable() {
        String[] columns = {"ID", "Name", "Seats", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablesTable = new JTable(tableModel);
        tablesTable.setRowHeight(32);
        JScrollPane scrollPane = new JScrollPane(tablesTable);
        scrollPane.setPreferredSize(new Dimension(0, 300));
        return scrollPane;
    }

    private JComponent createControls() {
        JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        controlsPanel.setOpaque(false);

        JButton addTableButton = new JButton("Add Table");
        addTableButton.setBackground(new Color(33, 150, 243));
        addTableButton.setForeground(Color.WHITE);
        addTableButton.addActionListener(e -> addNewTable());
        addTableButton.setEnabled(tableService.canManageTables(currentUser));

        JButton setAvailableButton = new JButton("Set Available");
        setAvailableButton.setBackground(new Color(56, 142, 60));
        setAvailableButton.setForeground(Color.WHITE);
        setAvailableButton.addActionListener(e -> setSelectedTableStatus("Available"));
        setAvailableButton.setEnabled(tableService.canManageTables(currentUser));

        JButton setOccupiedButton = new JButton("Set Occupied");
        setOccupiedButton.setBackground(new Color(245, 124, 0));
        setOccupiedButton.setForeground(Color.WHITE);
        setOccupiedButton.addActionListener(e -> setSelectedTableStatus("Occupied"));
        setOccupiedButton.setEnabled(tableService.canManageTables(currentUser));

        controlsPanel.add(addTableButton);
        controlsPanel.add(setAvailableButton);
        controlsPanel.add(setOccupiedButton);

        return controlsPanel;
    }

    private void addNewTable() {
        JTextField nameField = new JTextField();
        JTextField seatsField = new JTextField();
        
        Object[] message = {
            "Table Name:", nameField,
            "Number of Seats:", seatsField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add New Table", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String seatsStr = seatsField.getText().trim();
            
            if (name.isEmpty() || seatsStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            try {
                int seats = Integer.parseInt(seatsStr);
                if (seats < 1) {
                    JOptionPane.showMessageDialog(this, "Seats must be at least 1.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                boolean created = tableService.createTable(name, seats);
                if (created) {
                    loadTables();
                    JOptionPane.showMessageDialog(this, "Table '" + name + "' added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add table. Name may already exist.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Seats must be a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void loadTables() {
        tableModel.setRowCount(0);
        List<Table> tables = tableService.getAllTables();
        for (Table table : tables) {
            tableModel.addRow(new Object[]{
                    table.getId(),
                    table.getName(),
                    table.getSeats(),
                    table.getStatus()
            });
        }
    }

    private void setSelectedTableStatus(String status) {
        int selectedRow = tablesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a table.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int tableId = (int) tableModel.getValueAt(selectedRow, 0);
        String tableName = (String) tableModel.getValueAt(selectedRow, 1);

        boolean updated = tableService.updateTableStatus(tableId, status);
        if (updated) {
            loadTables();
            JOptionPane.showMessageDialog(this, "Table '" + tableName + "' status updated to " + status + ".", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update table status.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}