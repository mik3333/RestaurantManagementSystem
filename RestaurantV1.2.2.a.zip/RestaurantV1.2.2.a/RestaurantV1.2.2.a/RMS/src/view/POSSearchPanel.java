package view;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class POSSearchPanel extends JPanel {

    private final List<POSSearchListener> listeners = new ArrayList<>();
    private JTextField searchField;

    public POSSearchPanel() {
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setBackground(Color.WHITE);

        searchField = new JTextField(20);
        searchField.setText("Search products...");
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setForeground(Color.GRAY);
        searchField.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (searchField.getText().equals("Search products...")) {
                    searchField.setText("");
                    searchField.setForeground(Color.BLACK);
                }
            }
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setText("Search products...");
                    searchField.setForeground(Color.GRAY);
                }
            }
        });
        searchField.addActionListener(e -> {
            String query = searchField.getText();
            if (!query.equals("Search products...") && !query.trim().isEmpty()) {
                notifyListeners(query);
            }
        });

        JButton searchBtn = new JButton("Search");
        searchBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        searchBtn.setFocusPainted(false);
        searchBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        searchBtn.addActionListener(e -> {
            String query = searchField.getText();
            if (!query.equals("Search products...") && !query.trim().isEmpty()) {
                notifyListeners(query);
            }
        });

        add(searchField);
        add(searchBtn);
    }

    public void clearSearch() {
        searchField.setText("Search products...");
        searchField.setForeground(Color.GRAY);
    }

    public void addSearchListener(POSSearchListener listener) {
        listeners.add(listener);
    }

    private void notifyListeners(String query) {
        for (POSSearchListener listener : listeners) {
            listener.onSearch(query);
        }
    }

    public interface POSSearchListener {
        void onSearch(String query);
    }
}
