package view;

import service.OrderService;
import database.KitchenTicketDAO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class KitchenPanel extends JPanel {

    private final OrderService orderService = new OrderService();
    private JTable ticketsTable;
    private DefaultTableModel tableModel;

    public KitchenPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 242, 247));
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(createHeader(), BorderLayout.NORTH);
        add(createContent(), BorderLayout.CENTER);
    }

    private JComponent createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("Kitchen Orders");
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(39, 56, 103));

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(39, 56, 103));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        refreshBtn.addActionListener(e -> loadTickets());

        header.add(title, BorderLayout.WEST);
        header.add(refreshBtn, BorderLayout.EAST);

        return header;
    }

    private JComponent createContent() {
        JPanel content = new JPanel(new BorderLayout());
        content.setOpaque(false);

        // Table model
        String[] columns = {"Ticket #", "Order #", "Table", "Status", "Created At"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        ticketsTable = new JTable(tableModel);
        ticketsTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        ticketsTable.setRowHeight(25);
        ticketsTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        ticketsTable.getTableHeader().setBackground(new Color(39, 56, 103));
        ticketsTable.getTableHeader().setForeground(Color.WHITE);
        ticketsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(ticketsTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);

        JButton preparingBtn = new JButton("Set Preparing");
        preparingBtn.setBackground(new Color(255, 152, 0));
        preparingBtn.setForeground(Color.WHITE);
        preparingBtn.addActionListener(e -> updateTicketStatus("Preparing"));

        JButton readyBtn = new JButton("Set Ready");
        readyBtn.setBackground(new Color(56, 142, 60));
        readyBtn.setForeground(Color.WHITE);
        readyBtn.addActionListener(e -> updateTicketStatus("Ready"));

        JButton servedBtn = new JButton("Set Served");
        servedBtn.setBackground(new Color(33, 150, 243));
        servedBtn.setForeground(Color.WHITE);
        servedBtn.addActionListener(e -> updateTicketStatus("Served"));

        buttonPanel.add(preparingBtn);
        buttonPanel.add(readyBtn);
        buttonPanel.add(servedBtn);

        content.add(scrollPane, BorderLayout.CENTER);
        content.add(buttonPanel, BorderLayout.SOUTH);

        loadTickets();
        return content;
    }

    private void loadTickets() {
        tableModel.setRowCount(0);
        List<KitchenTicketDAO.KitchenTicketInfo> tickets = orderService.getKitchenTickets();

        for (KitchenTicketDAO.KitchenTicketInfo ticket : tickets) {
            String tableInfo = ticket.getTableId() != null ? "Table " + ticket.getTableId() : "Takeaway";
            tableModel.addRow(new Object[]{
                    ticket.getTicketNumber(),
                    ticket.getOrderNumber(),
                    tableInfo,
                    ticket.getStatus(),
                    formatDate(ticket.getCreatedAt())
            });
        }
    }

    private void updateTicketStatus(String newStatus) {
        int selectedRow = ticketsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a ticket to update.", 
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<KitchenTicketDAO.KitchenTicketInfo> tickets = orderService.getKitchenTickets();
        if (selectedRow >= tickets.size()) return;

        KitchenTicketDAO.KitchenTicketInfo ticket = tickets.get(selectedRow);
        boolean updated = orderService.updateKitchenTicketStatus(ticket.getId(), newStatus);

        if (updated) {
            loadTickets();
            JOptionPane.showMessageDialog(this, "Ticket status updated to " + newStatus, 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update ticket status.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String formatDate(String dateStr) {
        if (dateStr == null) return "N/A";
        try {
            return dateStr.substring(0, 19);
        } catch (Exception e) {
            return dateStr;
        }
    }
}