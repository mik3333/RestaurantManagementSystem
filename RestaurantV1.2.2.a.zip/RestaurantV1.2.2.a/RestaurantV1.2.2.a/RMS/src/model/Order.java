package model;

import java.util.List;

public class Order {
    private final int id;
    private final String orderNumber;
    private final int userId;
    private final Integer tableId; // Nullable
    private final String status;
    private final double subtotal;
    private final double tax;
    private final double discount;
    private final double total;
    private final String paymentStatus;
    private final String createdAt;
    private final String updatedAt;
    private final List<OrderItem> items;

    public Order(int id, String orderNumber, int userId, Integer tableId, String status,
                 double subtotal, double tax, double discount, double total, String paymentStatus,
                 String createdAt, String updatedAt, List<OrderItem> items) {
        this.id = id;
        this.orderNumber = orderNumber;
        this.userId = userId;
        this.tableId = tableId;
        this.status = status;
        this.subtotal = subtotal;
        this.tax = tax;
        this.discount = discount;
        this.total = total;
        this.paymentStatus = paymentStatus;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.items = items;
    }

    // Constructor for new orders
    public Order(String orderNumber, int userId, Integer tableId, List<OrderItem> items,
                 double subtotal, double tax, double discount, double total) {
        this(0, orderNumber, userId, tableId, "Open", subtotal, tax, discount, total, "Pending",
             null, null, items);
    }

    public int getId() { return id; }
    public String getOrderNumber() { return orderNumber; }
    public int getUserId() { return userId; }
    public Integer getTableId() { return tableId; }
    public String getStatus() { return status; }
    public double getSubtotal() { return subtotal; }
    public double getTax() { return tax; }
    public double getDiscount() { return discount; }
    public double getTotal() { return total; }
    public String getPaymentStatus() { return paymentStatus; }
    public String getCreatedAt() { return createdAt; }
    public String getUpdatedAt() { return updatedAt; }
    public List<OrderItem> getItems() { return items; }
}