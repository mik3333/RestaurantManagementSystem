package model;

public class Table {
    private final int id;
    private final String name;
    private final int seats;
    private final String status;

    public Table(int id, String name, int seats, String status) {
        this.id = id;
        this.name = name;
        this.seats = seats;
        this.status = status;
    }

    public Table(String name, int seats, String status) {
        this(0, name, seats, status);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getSeats() {
        return seats;
    }

    public String getStatus() {
        return status;
    }
}