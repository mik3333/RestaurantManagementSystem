package model;

public class OrderItem {
    private final int id;
    private final int orderId;
    private final int productId;
    private final int quantity;
    private final double unitPrice;
    private final double totalPrice;
    private final String notes;

    public OrderItem(int id, int orderId, int productId, int quantity, double unitPrice, double totalPrice, String notes) {
        this.id = id;
        this.orderId = orderId;
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.totalPrice = totalPrice;
        this.notes = notes;
    }

    // Constructor for new items
    public OrderItem(int productId, int quantity, double unitPrice, double totalPrice, String notes) {
        this(0, 0, productId, quantity, unitPrice, totalPrice, notes);
    }

    public int getId() { return id; }
    public int getOrderId() { return orderId; }
    public int getProductId() { return productId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) {
        // This allows quantity update for order merging
    }
    public double getUnitPrice() { return unitPrice; }
    public double getTotalPrice() { return totalPrice; }
    public String getNotes() { return notes; }
}