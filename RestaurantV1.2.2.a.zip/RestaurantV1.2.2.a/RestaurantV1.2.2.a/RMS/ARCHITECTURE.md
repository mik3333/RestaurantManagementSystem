# Restaurant Management System - Architecture Guide

## Overview

The application is organized into a modular, layered architecture for easy maintenance and future updates:

```
├── model/              # Data models (User, Product)
├── database/          # Database access layer (DAO classes)
├── service/           # Business logic layer (Services)
├── controller/        # Application controllers
└── view/              # UI layer (Panels, Components)
    ├── Theme files
    ├── Component factory
    └── UI Panels
```

## Layer Architecture

### 1. **Model Layer** (`model/`)
Contains data model classes that represent entities.
- `User.java` - User account model
- `Product.java` - Product catalog model

**Update when:** Adding new entity attributes or data types.

---

### 2. **Database Layer** (`database/`)
Contains Data Access Objects (DAOs) for direct database operations.
- `DatabaseManager.java` - JDBC connection management
- `UserDAO.java` - User database operations
- `ProductDAO.java` - Product database operations

**Update when:** Changing SQL queries or adding new database operations.
**Do NOT update directly for UI changes** - use the Service layer instead.

---

### 3. **Service Layer** (`service/`)
**This is the layer you should update for most changes.**

Contains business logic that sits between UI and database:
- `StaffService.java` - User/staff management logic
  - All staff operations (create, delete, edit)
  - Permission checks
  - Validation logic
  
- `ProductService.java` - Product management logic
  - Product operations
  - Data validation

**Benefits:**
- Changes to business rules only require updating service classes
- UI doesn't need to know database implementation details
- Easy to test and modify logic without affecting UI

**Update when:**
- Adding new business rules
- Changing permission logic
- Modifying validation
- Adding new features

---

### 4. **View Layer** (`view/`)

#### **Styling & Theming**
- `ThemeConstants.java` - Centralized color, font, and spacing definitions
  - Update colors here and all UI components automatically use the new theme
  - **Update when:** Changing design/brand colors, fonts, or spacing

#### **UI Components**
- `UIComponentFactory.java` - Factory for creating styled components
  - Provides methods like `createPrimaryButton()`, `createStyledTextField()`, etc.
  - Ensures all UI elements follow the theme
  - **Update when:** Adding new component types or changing component behavior

#### **Panels**
- `UsersPanel.java` - Staff management UI (refactored with new architecture)
- `ProductsPanel.java` - Product management UI
- Other panels: Dashboard, LoginForm, etc.

**Update when:** Adding UI features or modifying panel layouts.

---

## How to Make Common Updates

### Update Colors/Fonts/Spacing
1. Open `ThemeConstants.java`
2. Modify the constants (e.g., `PRIMARY_COLOR`, `TITLE_FONT`)
3. All UI components automatically use the new values

**Example:** Change primary color from pink to blue:
```java
public static final Color PRIMARY_COLOR = new Color(33, 150, 243); // Blue
```

### Update Styled Components
1. Open `UIComponentFactory.java`
2. Modify the component creation methods
3. All panels using these components are automatically updated

**Example:** Add border radius to buttons:
```java
public static JButton createPrimaryButton(String text) {
    JButton button = new JButton(text);
    // ... existing code ...
    button.setBorder(new RoundedBorder(ThemeConstants.CORNER_RADIUS));
    return button;
}
```

### Add Permission Rules
1. Open `StaffService.java` (or `ProductService.java`)
2. Add new methods or modify existing permission checks
3. UI automatically enforces new rules without changes

**Example:** Add new role permission:
```java
public boolean canDeleteProduct(User user) {
    return user.getRole().equals("Admin");
}
```

### Update Business Logic
1. Modify the appropriate Service class
2. UI panels automatically use updated logic
3. No database or UI changes needed

---

## File Dependencies

```
View Panels (UI)
    ↓
Service Layer (Business Logic)
    ↓
Database Layer (DAOs)
    ↓
Database (SQL)

UI Components
    ↓
Theme Constants
```

**Key Rule:** Never skip layers. Always go through the Service layer for UI operations.

---

## Adding a New Feature

### Example: Add user edit dialog

1. **Service Layer** - Add method in `StaffService.java`:
```java
public boolean updateStaffDetails(String username, String newPassword) {
    return userDAO.updatePassword(username, newPassword);
}
```

2. **Database Layer** - Add method in `UserDAO.java`:
```java
public boolean updatePassword(String username, String newPassword) {
    // SQL implementation
}
```

3. **View Layer** - Add button in `UsersPanel.java`:
```java
JButton editButton = UIComponentFactory.createSecondaryButton("Edit");
editButton.addActionListener(e -> {
    boolean updated = staffService.updateStaffDetails(username, newPassword);
    // handle result
});
```

---

## Testing Updates

After making changes, verify:

1. **Compilation:** All classes compile without errors
2. **Functionality:** Test the specific feature works
3. **Consistency:** Check UI uses correct theme colors/fonts
4. **Permissions:** Verify role-based access still works

---

## File Structure Summary

| File | Purpose | Update Frequency |
|------|---------|------------------|
| `ThemeConstants.java` | Design system | Low (design changes) |
| `UIComponentFactory.java` | Component library | Low (new component types) |
| `StaffService.java` | Staff logic | Medium (business rules) |
| `ProductService.java` | Product logic | Medium (business rules) |
| `*DAO.java` | Database queries | Low (new data operations) |
| `*Panel.java` | UI layouts | Medium (feature additions) |

---

## Best Practices

✅ **DO:**
- Update Service classes for business logic changes
- Use `ThemeConstants` for all colors/fonts
- Use `UIComponentFactory` for all UI components
- Keep UI Panels focused on display logic only

❌ **DON'T:**
- Hardcode colors in UI panels
- Mix database queries with UI code
- Create direct database connections outside DAOs
- Update multiple layers for a single feature

---

## Maintenance Checklist

Before deploying changes:
- [ ] All files compile with no errors
- [ ] Service layer methods have clear documentation
- [ ] New UI components use `ThemeConstants`
- [ ] Permission checks use Service layer methods
- [ ] Database operations go through DAOs only
- [ ] Tested with different user roles (Admin, Manager, Cashier)
