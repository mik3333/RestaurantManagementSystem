package service;

import database.ProductDAO;
import model.Product;

import java.util.List;

/**
 * Service layer for product management operations.
 * Encapsulates business logic and provides a clean interface for UI components.
 * Update this class instead of database classes to modify product management behavior.
 */
public class ProductService {

    private final ProductDAO productDAO;

    public ProductService() {
        this.productDAO = new ProductDAO();
    }

    /**
     * Get all products in the catalog
     */
    public List<Product> getAllProducts() {
        return productDAO.findAll();
    }

    /**
     * Add a new product to the catalog
     */
    public boolean addProduct(String name, String category, double price, String description) {
        return productDAO.createProduct(name, category, price, description);
    }

    /**
     * Remove a product from the catalog
     */
    public boolean removeProduct(int productId) {
        return productDAO.deleteProduct(productId);
    }

    /**
     * Update product information
     */
    public boolean updateProduct(int productId, String name, String category, double price, String description) {
        return productDAO.updateProduct(productId, name, category, price, description);
    }

    /**
     * Validate product data before saving
     */
    public String validateProduct(String name, String category, String priceStr, String description) {
        if (name.isEmpty() || category.isEmpty() || priceStr.isEmpty()) {
            return "Please fill in all required fields.";
        }

        try {
            Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            return "Price must be a valid number.";
        }

        return null; // No errors
    }

    /**
     * Parse price string to double
     */
    public double parsePrice(String priceStr) throws NumberFormatException {
        return Double.parseDouble(priceStr);
    }
}
