package database;

import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;

public class DatabaseManager {
    private static final String DB_FILE = "data/restaurant.db";
    private static final String SCHEMA_FILE = "database/schema.sql";
    private static final String JDBC_URL = "jdbc:sqlite:" + DB_FILE;

    public static Connection connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            loadDriverJar();
        }
        return DriverManager.getConnection(JDBC_URL);
    }

    private static void loadDriverJar() throws SQLException {
        Path jarPath = Paths.get("lib", "sqlite-jdbc-3.42.0.0.jar");
        if (!Files.exists(jarPath)) {
            throw new SQLException("SQLite JDBC driver jar not found at: " + jarPath.toAbsolutePath());
        }

        try {
            URL jarUrl = jarPath.toUri().toURL();
            URLClassLoader loader = new URLClassLoader(new URL[]{jarUrl}, Thread.currentThread().getContextClassLoader());
            Class<?> driverClass = Class.forName("org.sqlite.JDBC", true, loader);
            Driver driver = (Driver) driverClass.getDeclaredConstructor().newInstance();
            DriverManager.registerDriver(new DriverShim(driver));
        } catch (Exception ex) {
            throw new SQLException("Failed to load SQLite JDBC driver from jar", ex);
        }
    }

    public static void initializeDatabase() throws IOException, SQLException {
        Path dbDir = Paths.get("data");
        if (!Files.exists(dbDir)) {
            Files.createDirectories(dbDir);
        }

        String schema = readSchema();
        try (Connection connection = connect(); Statement statement = connection.createStatement()) {
            Arrays.stream(schema.split(";"))
                    .map(String::trim)
                    .filter(sql -> !sql.isEmpty())
                    .forEach(sql -> {
                        try {
                            statement.execute(sql);
                        } catch (SQLException e) {
                            throw new RuntimeException("Failed to execute SQL statement: " + sql, e);
                        }
                    });
        }
    }

    private static String readSchema() throws IOException {
        Path schemaPath = Paths.get(SCHEMA_FILE);
        if (!Files.exists(schemaPath)) {
            throw new IOException("Schema file not found: " + SCHEMA_FILE);
        }
        return Files.readString(schemaPath, StandardCharsets.UTF_8);
    }

    private static class DriverShim implements Driver {
        private final Driver delegate;

        public DriverShim(Driver delegate) {
            this.delegate = delegate;
        }

        @Override
        public Connection connect(String url, Properties info) throws SQLException {
            return delegate.connect(url, info);
        }

        @Override
        public boolean acceptsURL(String url) throws SQLException {
            return delegate.acceptsURL(url);
        }

        @Override
        public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {
            return delegate.getPropertyInfo(url, info);
        }

        @Override
        public int getMajorVersion() {
            return delegate.getMajorVersion();
        }

        @Override
        public int getMinorVersion() {
            return delegate.getMinorVersion();
        }

        @Override
        public boolean jdbcCompliant() {
            return delegate.jdbcCompliant();
        }

        @Override
        public Logger getParentLogger() throws SQLFeatureNotSupportedException {
            return delegate.getParentLogger();
        }
    }
}
