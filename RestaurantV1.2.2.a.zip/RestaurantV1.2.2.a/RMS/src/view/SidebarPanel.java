package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class SidebarPanel extends JPanel {

    private final SidebarListener listener;

    public SidebarPanel(SidebarListener listener) {
        this.listener = listener;

        setLayout(new BorderLayout());
        setBackground(new Color(34, 44, 82));
        setPreferredSize(new Dimension(220, 0));

        add(createBrandPanel(), BorderLayout.NORTH);
        add(createMenuPanel(), BorderLayout.CENTER);
        add(createFooterPanel(), BorderLayout.SOUTH);
    }

    private JComponent createBrandPanel() {
        JPanel brand = new JPanel();
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));
        brand.setBackground(new Color(34, 44, 82));
        brand.setBorder(new EmptyBorder(24, 20, 24, 20));

        JLabel icon = new JLabel("\uD83C\uDF7D", SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 46));
        icon.setForeground(Color.WHITE);
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("POS System", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(new EmptyBorder(12, 0, 0, 0));

        brand.add(icon);
        brand.add(title);
        return brand;
    }

    private JComponent createMenuPanel() {
        JPanel menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBackground(new Color(34, 44, 82));
        menu.setBorder(new EmptyBorder(10, 0, 10, 0));

        String[] menuItems = {
            "Home", "Categories", "Products",
            "Tables", "Staff", "POS",
            "Kitchen", "Reports", "Settings"
        };

        for (String item : menuItems) {
            JButton btn = createMenuButton(item);
            menu.add(btn);
            menu.add(Box.createVerticalStrut(8));
        }

        return menu;
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(new Color(34, 44, 82));
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> listener.onMenuSelected(text));
        return btn;
    }

    private JComponent createFooterPanel() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(new Color(34, 44, 82));
        footer.setBorder(new EmptyBorder(16, 20, 20, 20));

        JButton exitBtn = new JButton("Exit");
        exitBtn.setFocusPainted(false);
        exitBtn.setBackground(new Color(211, 47, 47));
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setOpaque(true);
        exitBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        exitBtn.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        exitBtn.addActionListener(e -> System.exit(0));

        footer.add(exitBtn, BorderLayout.SOUTH);
        return footer;
    }
}